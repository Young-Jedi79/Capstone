#!/usr/bin/env python
# coding: utf-8

# In[1]:


pip install pytorch_lightning


# In[2]:


pip install ipython


# In[3]:


pip install pyarrow


# In[4]:


pip install yfinance


# In[5]:


pip install --upgrade yfinance


# In[6]:


pip install mpl_finance


# In[7]:


get_ipython().system('pip install mplfinance==0.12.9b1')
get_ipython().system('pip install yfinance==0.1.66')
get_ipython().system('pip install fredapi')


# ### Introduction
# 
# #### The S&P 500 (Standard & Poor's 500)
# 
# Is a market-capitalization-weighted index of 500 of the largest publicly traded companies in the United States. Widely regarded as one of the best indicators of the U.S. stock market and a leading benchmark for the performance of the broader economy, the S&P 500 is closely monitored by investors, analysts, and financial professionals.
# 
# Before getting started with the visualization part lets understand the meaning of these feature terms :-
# 
# Open: Open means the price at which a stock started trading when the opening bell rang.
# 
# Close: Close refers to the price of an individual stock when the stock exchange closed for the day. It represents the last buy-sell order executed between two traders
# 
# High: The high is the highest price at which a stock is traded during a period.
# 
# Low: The low is the lowest price of the period.
# 
# Adj Close: Adjusted values factor in corporate actions such as dividends, stock splits, and new share issuance
# 
# Volume: Volume is the total number of shares traded in a security period.
# 
# Stock’s closing price determines how a share performs during the day.
# When researching historical stock price data, financial institutions, regulators, and individual investors use the closing price as the standard measure of the stock’s value as of a specific date. For example, a stock’s close on December 31, 2023, was the closing price for that day and that week, month, quarter, and year.
# The difference between the stocks open and close divided by the open is the stock’s return or performance in percentage terms.
# 
# 
# #### Time Series
# Time-series data is a collection of data points over a set period. Plot the points on a graph, and one of your axes would always be time.
# 
# What sets time series data apart from other data is that the analysis can show how variables change over time.
# 
# The frequency of recorded data points may be hourly, daily, weekly, monthly, quarterly or annually.
# 
# In other words, time is a crucial variable because it shows how the data adjusts over the course of the data points as well as the final results. It provides an additional source of information and a set order of dependencies between the data.
# 
# The time series data may be of three types:-
# 
# Time series data - The observations of the values of a variable recorded at different points in time is called time series data.
# 
# Cross sectional data - It is the data of one or more variables recorded at the same point in time. Ex:-gross annual income for each of 1000 randomly chosen households in New York City for the year 2000.
# 
# Pooled data- It is the combination of time series data and cross sectional data.
# 
# ### Time Series Analysis
# 
# Time-series analysis is a method of analyzing data to extract useful statistical information and characteristics.
# 
# A time series analysis encompasses statistical methods for analyzing time series data. These methods enable us to extract meaningful statistics, patterns and other characteristics of the data.
# 
# Time series are visualized with the help of line charts. So, time series analysis involves understanding inherent aspects of the time series data so that we can create meaningful and accurate forecasts.
# 
# One of the study's main goals is to predict future value.
# 
# ### Time Series Analysis Types
# 
# Classification: It identifies and assigns categories to the data.
# 
# Curve Fitting: It plots data on a curve to investigate the relationships between variables in the data.
# 
# Descriptive Analysis: Patterns in time-series data, such as trends, cycles, and seasonal variation, are identified.
# 
# Explanative analysis: It attempts to comprehend the data and the relationships between it and cause and effect.
# 
# Segmentation: It splits the data into segments to reveal the source data's underlying properties.
# 
# ### Components of a Time-Series
# Trend - The trend shows a general direction of the time series data over a long period of time. A trend can be increasing(upward), decreasing(downward), or horizontal(stationary). 
# 
# Seasonality - The seasonality component exhibits a trend that repeats with respect to timing, direction, and magnitude. Some examples include an increase in water consumption in summer due to hot weather conditions.
# 
# Noise - Outliers or missing values
# 
# Cyclical Component - These are the trends with no set repetition over a particular period of time. A cycle refers to the period of ups and downs, booms and slums of a time series, mostly observed in business cycles. These cycles do not exhibit a seasonal variation but generally occur over a time period of 3 to 12 years depending on the nature of the time series.
# 
# Irregular Variation - These are the fluctuations in the time series data which become evident when trend and cyclical variations are removed. These variations are unpredictable, erratic, and may or may not be random.
# 
# ETS Decomposition - ETS Decomposition is used to separate different components of a time series. The term ETS stands for Error, Trend and Seasonality.

# In[ ]:


import warnings
warnings.filterwarnings('ignore')

import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import mean_squared_error

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
get_ipython().run_line_magic('matplotlib', 'inline')
import seaborn as sns
import matplotlib.ticker as ticker
import scipy as sc
import matplotlib.animation as animation

import plotly as plotly
import plotly.express as px
import plotly.graph_objects as go
import plotly.io as plotly
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import plotly.express as ex
import plotly.graph_objs as go
import plotly.offline as pyo
from plotly.offline import download_plotlyjs, init_notebook_mode, plot, iplot
from plotly.subplots import make_subplots
pyo.init_notebook_mode()



from statsmodels.graphics.tsaplots import plot_pacf
from statsmodels.graphics.tsaplots import plot_acf
from statsmodels.tsa.statespace.sarimax import SARIMAX
from statsmodels.tsa.holtwinters import ExponentialSmoothing
from statsmodels.tsa.stattools import adfuller, acf,pacf
from statsmodels.tsa.stattools import kpss
from statsmodels.tsa.arima_model import ARIMA, ARMA
from datetime import datetime
import statsmodels.api as sm
from statsmodels.tsa.stattools import adfuller
from statsmodels.tsa.seasonal import seasonal_decompose
from statsmodels.tsa.arima.model import ARIMA
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf

from pmdarima.arima import auto_arima

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import confusion_matrix, classification_report, accuracy_score
from sklearn.manifold import TSNE
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import MinMaxScaler

from sklearn.metrics import mean_squared_error, mean_absolute_error
import math

from tensorflow import keras
from tensorflow.keras.layers import Dense,LSTM,Dropout,Flatten
from tensorflow.keras import Sequential

from keras.preprocessing.text import Tokenizer
from keras.preprocessing.sequence import pad_sequences
from keras.models import Sequential
from keras.layers import Activation, Dense, Dropout, Embedding, Flatten, Conv1D, MaxPooling1D, LSTM
from keras import utils
from keras.callbacks import ReduceLROnPlateau, EarlyStopping

import nltk
from nltk.corpus import stopwords
from  nltk.stem import SnowballStemmer

import gensim

from transformers import AutoTokenizer, AutoModelForSequenceClassification
from scipy.special import softmax

from textblob import TextBlob
from textblob import TextBlob

import gensim

import re
import numpy as np
import os
from collections import Counter
import logging
import time
import pickle
import itertools

logging.basicConfig(format='%(asctime)s : %(levelname)s : %(message)s', level=logging.INFO)


from itertools import product
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
from sklearn.metrics import median_absolute_error, mean_squared_log_error

import gc
import copy
from pathlib import Path
from datetime import datetime, timedelta, date
import time
from dateutil.relativedelta import relativedelta 

import pyarrow.parquet as pq
import pyarrow as pa

from tqdm import tqdm

import yfinance as yf

from collections import Counter
from scipy.stats import chi2_contingency
from wordcloud import WordCloud, STOPWORDS

from sklearn.svm import LinearSVC
from sklearn.naive_bayes import BernoulliNB
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import confusion_matrix, classification_report

import string
import nltk
import matplotlib.pyplot as plt
import seaborn as sns
sns.set_style('darkgrid')

from sklearn.decomposition import TruncatedSVD,PCA
from sklearn.feature_extraction.text import CountVectorizer
nltk.download('vader_lexicon')
from sklearn.cluster import KMeans

from pandas.plotting import autocorrelation_plot
from statsmodels.graphics.tsaplots import plot_acf
from statsmodels.graphics.tsaplots import plot_pacf
from statsmodels.tsa.seasonal import seasonal_decompose
import random
plt.rc('figure',figsize=(17,13))

import yfinance as yf

import pytorch_lightning as pl
random_seed=1
pl.seed_everything(random_seed)

import os
import gc
import copy
from pathlib import Path
from datetime import datetime, timedelta, date
import time
from dateutil.relativedelta import relativedelta 

import pyarrow.parquet as pq
import pyarrow as pa

from matplotlib import gridspec
from sklearn import tree, metrics
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import fbeta_score, make_scorer
from datetime import datetime, timedelta
from pylab import rcParams
import os
import importlib
import sys
import warnings
if not sys.warnoptions:
    warnings.simplefilter("ignore")
from prepare_data import DataLoader
from evaluate_results import EvaluateResults


# ### Loading the Dataset

# In[9]:


df_2009 = pd.read_csv('^SPX.csv')
df_2010 = pd.read_csv('^BSESN.txt')
df_2011 = pd.read_csv('^BVSP.txt')
df_2013 = pd.read_csv('^GDAXI.txt')
df_2014 = pd.read_csv('^HSI.txt')
df_2015 = pd.read_csv('^MXX.txt')
df_2016 = pd.read_csv('^N225.txt')
df_2017 = pd.read_csv('^NDX.txt')
df_2018 = pd.read_csv('^SSMI.txt')
df_2019 = pd.read_csv('SSE.txt')


# Concatinate the datasets

# In[10]:


dataframes = [df_2009, df_2010, df_2011, df_2013, df_2014, df_2015, df_2016, df_2017, df_2018, df_2019]
df = pd.concat(dataframes, ignore_index=True, axis=0)


# In[11]:


df.head()


# Before getting started with the visualization part lets understand the meaning of these feature terms :-
# 
# Open -> Open means the price at which a stock started trading when the opening bell rang.
# 
# Close -> Close refers to the price of an individual stock when the stock exchange closed shop for the day. It represents the last buy-sell order executed between two traders
# 
# High -> The high is the highest price at which a stock is traded during a period.
# Low -> The low is the lowest price of the period.
# 
# Adj Close -> Adjusted values factor in corporate actions such as dividends, stock splits, and new share issuance
# 
# Volume -> Volume is the total number of shares traded in a security period.
# 
# Why is a Stock’s Closing Price Significant?
# 
# Stock’s closing price determines how a share performs during the day.
# When researching historical stock price data, financial institutions, regulators, and individual investors use the closing price as the standard measure of the stock’s value as of a specific date. For example, a stock’s close on December 31, 2019, was the closing price for that day and that week, month, quarter, and year.
# The difference between the stocks open and close divided by the open is the stock’s return or performance in percentage terms.

# In[12]:


df


# I will now use the function describe, because apply descriptive statistics that summarize the central tendency, dispersion, and shape of my dataset’s distribution, excluding NaN values. It analyzes both numeric and object series, as well as DataFrame column sets of mixed data types.

# In[13]:


df.describe()


# In[14]:


df.columns


# #### Missing Values
# 
# I will now check how missing values are in our remaining features and then decide whether to drop them or replace them with a meaningful value.
# 
# By calling the .isnull().sum(), isnull().mean(), value_counts() and .describe() functions I can check the number of standard missing values in our DataFrame.

# In[15]:


df.isnull().sum()


# In[16]:


df.isnull().mean()*100


# .isna () function is used to detect missing values. It return a boolean same-sized object indicating if the values are NA. NA values, such as None or numpy.NaN, gets mapped to True values. Everything else gets mapped to False values.

# In[17]:


df.isna()


# Lets look for the amount of null values

# In[18]:


df.isna().sum().sum()


# In[19]:


count_missing = ((df.isnull().sum()).sort_values(ascending=True))
count_missing


# In[20]:


print(df.columns)


# The following code will detail the percentage of info missing in the dataset.

# In[21]:


percentage_missing = (round(df.isnull().  sum() * 100/ len(df),2).sort_values(ascending=False))
display(pd.DataFrame({'Missing Percentage' :percentage_missing}));


# Lets now see how many numerical features are there in the dataframe

# In[22]:


len(df.select_dtypes(exclude='object').columns)


# The next function will return the amount of duplicated values in the dataframe

# In[23]:


df.duplicated().sum()


# Duplicate rows:
# 
# There are 438 duplicate rows and I decided to drop them for now and make the change to the DataFrame permanent using the .drop_duplicates(inplace = True) functio

# In[24]:


duplicate_rows = df[df.duplicated()]


# In[25]:


duplicate_rows.shape


# In[26]:


df.drop_duplicates(inplace = True)


# In[27]:


missing_data = df[df['Close'].isnull()]


# In[28]:


missing_data


# In[29]:


missing_data = df[df['Close'].isnull()]


# In[30]:


df['Close'] = df['Close'].fillna(df['Close'].mean())


# In[ ]:





# ### Number of distinct values in each feature

# In[31]:


for col in df.columns:
    print(col, ': Number of Distinct Values: ', len(df[col].unique()))


# ### Print the distinct values in each feature.

# In[32]:


for col in df:
    print('COLUMN NAME: ', col,':')
    print(df[col].unique())
    print('\n')


# #### I will now call the .describe() function to quickly analyse the summary statistics for the numerical features.

# In[33]:


df.describe().T


# In[34]:


print('length of data is', len(df))


# In[35]:


df.dtypes


# In[36]:


df.dtypes.value_counts()


# I will visualize how many Qualitative features are there in the dataset

# In[37]:


qualitative=[feature for feature in df.columns if len(df[feature].unique())<=10]
qualitative


# As we can see, there is 1 qualitative feature in the dataset
# 
# I will now analise the amount of unique values in the qualitative features
# 
# Quantitative data represents numerical data and qualitative represents Categorical data

# In[38]:


for feature in qualitative:
    print(feature)
    print(df[feature].unique())


# The following code tells me the amount of quantitative variables in the dataframe.

# In[39]:


quantitative=[feature for feature in df.columns if df[feature].dtype!='O' and
             len(df[feature].unique())>10]
quantitative


# I will now use Histogram to visualize the distribution of quantitative featuresby using the function count in the quantitative columns

# In[40]:


for feature in quantitative:
    sns.histplot(df[feature])
    plt.show()


# ### Data Cleaning

#  I will now change the date feature from an object datatype to a datetime format for a more concize manipulation of date and time.

# In[41]:


df['Date'] = pd.to_datetime(df['Date'])


# In[42]:


pd.to_datetime(df['Date'].astype(str), format='%Y-%m-%d')


# In[43]:


pd.to_datetime(df['Date'].astype(str), format='%Y-%m-%d')


# I will compute the amount of days between the limits in the table

# In[44]:


df.Date.max()-df.Date.min()


# I will now convert all columns to numeric so that I can perform statistical analyses or visualizations. Dirty numeric data in a series will often be inferred by Pandas as the datatype 'object'. Once I've got the data fairly clean, I can use pd.to_numeric() to convert a series into a numeric data type.

# In[45]:


df['Open'] = pd.to_numeric(df['Open'])
df['High'] = pd.to_numeric(df['High'])
df['Low'] = pd.to_numeric(df['Low'])
df['Close'] = pd.to_numeric(df['Close'])
df['Volume'] = pd.to_numeric(df['Volume'])


# I will set date feature as index

# In[46]:


df = df.set_index(df['Date']).sort_index() 
print(df.shape)
df.sample(5)


# The following command will help me understand when did the first stock market trading happened by selecting rows where the volume column has values greater than 0.

# In[47]:


data = df[df['Volume']>0]
data.head(3)


# We can see that the first stock market trading happened on 1950/01/03 with 1260000 Stocks being traded

# I want to see when did stock market trading actually picked up.
# 
# By using pandas library to create a plot of the Volume column, I will generate and display a line plot with the specified figure size. The x-axis represent the index of the Dataframe and the y axis represent the volume values.

# In[48]:


df['Volume'].plot(figsize=(15,5))


# We can see small oscilations on early 1990's but the real change in trading started around 2000

# I will now plot the data for a visual check.
# 
# This code generates a line plot where the 'Date' column is used for the x-axis, and the 'High' column is used for the y-axis. When executing this code, I will create and display a line plot where the x-axis represents dates and the y-axis represents the 'High' values. This plot allows me to visualize the high values of the data over time, showing any trends or patterns in the 'High' column.

# In[49]:


df.plot(x="Date",y="High")


# #### Plotting the Time Series - Visualizing the Signal
# 
# Using Plotly express, the resulting plot will show the 'Close' values over time, and it will have a custom interactive appearance with the specified colors, fonts, and layout settings. The 'Close' values are displayed on the y-axis, and the dates are displayed on the x-axis.The plot will be interactive and values will appear when hoovered on the actual line graph. The graph can be zoomed as well.

# In[50]:


px.defaults.template = "ggplot2"
fig = px.line(df, y='Close',width=950, height=750)
fig.update_traces(line_color="#0c8f8f")

m = dict(
    l = 10,
    r = 10,
    b= 80,
    t = 80,
    pad = 30)
    

fig.update_layout(margin=m,paper_bgcolor="#bdbfc0")
fig.update_yaxes(title_text='<b>Number of Closes over time</b>', row=1, 
                 col=1,tickfont_size=10,titlefont = dict(size = 14))
fig.update_xaxes(title_text='<b>Date</b>', row=1, 
                 col=1,tickfont_size=10,titlefont = dict(size = 14))
    
fig.show()


# Visual Findings:
# 
# 1. The time series shows trend going up from 1990.
# 
# 2. Seasonality is evident as well, the number of drop in closes is evident in Sep 2000, Oct 2007, Feb 2020 and Dec 2021.

# The following histogram will display the distribution of data in the DataFrame using 80 bins. It provides insights into the distribution of values within the dataset and will help me understand the data's central tendency and spread. The x-axis represents the values or intervals, and the y-axis represents the frequency or count of data points in each bin.

# In[51]:


df.hist(bins=80, figsize=(20,10))


# The following code will assist in creating a barplot displaying the percentage of change High for each feature.
# 
# I used the percent_and_barplot due to its usefulness to quickly explore and visualize the distribution of data in the dataframe column, by providing both the percentages and a visual representation of the counts of unique values in the column.

# In[52]:


def percent_and_barplot(col):
    print(round(df[col].value_counts()/len(df)*100,2))
    df[col].value_counts().plot(kind='bar')
    plt.ylabel('count')
    plt.title(col);


# #### Visualization of the Stock price Dataset

# A stock price is a given for every share issued by a publicly-traded company. 
# The price is a reflection of the company's value and what the public is willing to pay for a percentage of the company. It can and will rise and fall, based on a variety of factors in the global landscape and within the company itself.

# Plot closing prices of the S&P 500 Index over the specified time period, with dates on x-axis and closing prices on y-axis.

# In[53]:


plt.figure(figsize=(12, 6))
plt.plot(df['Date'], df['Close'], label='Closing Prices')
plt.title('S&P 500 Closing Prices Over Time')
plt.xlabel('Date')
plt.ylabel('Closing Price')
plt.legend()
plt.show()


# The following plot will display the time series of the 'Close' prices from the 'data' DataFrame, with dates on the x-axis and 'Close' prices on the y-axis. The specified figure size controls the dimensions of the plot.

# In[54]:


data['Close'].plot(figsize=(15,5))


# The following code will use the Seaborn library to create a Kernel Density Estimate (KDE) plot for the 'Close'column with 'data' with shading.
# 
# The shaded area under the curve will represent the estimated density, making it useful to visualize the distribution of data and identifying potential patterns in the data.

# In[55]:


sns.kdeplot(data['Close'], shade=True)


# I will now use plotly to interactively visualize the close price of the dataset.
# 
# The code uses Plotly Express (px) to create a line chart of the closing prices of the dataset. It includes a range slider and date range selector in the x-axis. 
# 
# The following functions allows me to select the 1 Month range, 6 Month range, Year to Date range and 1 year range:  
# 
# dict(count=1,label="1m",step="month",stepmode="backward"),
#         dict(count=6,label="6m",step="month",stepmode="backward"),
#         dict(count=1,label="YTD",step="year",stepmode="todate"),
#         dict(count=1,label="1y",step="year",stepmode="backward"),
#         dict(step="all")

# In[56]:


fig = px.line(data,x="Date",y="Close",title="Closing Price: Range Slider and Selectors")
fig.update_xaxes(rangeslider_visible=True,rangeselector=dict(
    buttons=list([
        dict(count=1,label="1m",step="month",stepmode="backward"),
        dict(count=6,label="6m",step="month",stepmode="backward"),
        dict(count=1,label="YTD",step="year",stepmode="todate"),
        dict(count=1,label="1y",step="year",stepmode="backward"),
        dict(step="all")
])))


# Now I am ready to calculate the S&P 500 daily returns and add to the DataFrame as a new column that we will call Return and will make a copy to use at a later stage.
# 
# Creating a return column in financial data is common financial analysis and time series analysis due to several factors such as performance measurement, risk assessment, statistical analysis, time series analysis, visualization, comparisons and benchmarking.
# 
# Therefore by calculating and maintaining a return column is crucial for financial analysis, risk management and investment decision making.

# In[57]:


df['Return'] = (df['Adj Close']-df['Open'])/df['Open']

stocks_data = df.copy()

df.head(5)


# I will now use plotly to visualize the Returns since stock market since its early records.
# 
# fig.update_xaxes(rangeslider_visible=True, rangeselector=dict(buttons=list([...])))): This code updates the x-axis settings of the plot. It enables a range slider (rangeslider_visible=True) and a range selector (rangeselector=dict(buttons=list([...]))) for selecting different time periods.
# 
# buttons=list([...]): This list defines different time period buttons that allow users to select predefined date ranges (e.g., 1 month, 6 months, YTD, 1 year, all data).
# 
# Each button is defined as a dictionary with properties like 'count' (the number of time periods), 'label' (the label for the button), 'step' (the time period step, e.g., "month" or "year"), and 'stepmode' (how the step is applied, e.g., "backward" or "todate").

# In[58]:


fig = px.line(df,x="Date",y="Return",title="Returns : Range Slider and Selectors")
fig.update_xaxes(rangeslider_visible=True,rangeselector=dict(
    buttons=list([
        dict(count=1,label="1m",step="month",stepmode="backward"),
        dict(count=6,label="6m",step="month",stepmode="backward"),
        dict(count=1,label="YTD",step="year",stepmode="todate"),
        dict(count=1,label="1y",step="year",stepmode="backward"),
        dict(step="all")
])))


# #### Candlestick plots
# 
# The candlestick chart is a style of financial chart describing open, high, low and close for a given x coordinate (most likely time). The boxes represent the spread between the open and close values and the lines represent the spread between the low and high values. Sample points where the close value is higher (lower) then the open value are called increasing (decreasing). By default, increasing candles are drawn in green whereas decreasing are drawn in red.

# The following modules and functions are related to creating candlestick charts using Matplotlib for financial data visualization. 

# In[59]:


from matplotlib.dates import DateFormatter, WeekdayLocator, DayLocator
from mpl_finance import candlestick_ohlc
import matplotlib.dates as mdates


# Now I want to add a Candlestick screenshot into my jupyter notebook, therefore I will use the function IPython.display and specify the image class.

# In[60]:


#from IPython.display import Image

#screenshot_path = "C:\\Users\\edmun\\OneDrive\\Pictures\\Screenshots\\Screenshot 2023-12-27 214925.png"

#Image(filename=screenshot_path)


# I will next create a candlestick chart using Plotly Library, which will be useful to visualize price movements of stocks.
# 
# The go.Figure object will be created by using go.Figure(data=[go.Candlestick(...)]) which will specify the candlestick chartds data and properties.

# In[61]:


fig = go.Figure(data=[go.Candlestick(x=df['Date'],
                                    open=df['Open'],
                high=df['High'],
                low=df['Low'],
                close=df['Close'])])
fig.show()


# ### Time Series Data Analysis - Resampling
# 
# In time series, data consistency is of prime importance, resampling ensures that the data is distributed with a consistent frequency.
# Resampling can also provide a different perception of looking at the data.
# In other words, it can add additional insights about the data based on the resampling frequency.
# Upsampling - Time series is resampled from low frequency to high frequency (Monthly to daily frequency). It involves filling or interpolating missing data
# 
# Downsampling - Time series is resampled from high frequency to low frequency (Weekly to monthly frequency). It involves aggregation of existing data.
# 
# Time series datasets with a high frequency of data points (e.g., daily or monthly) can be computationally intensive, especially when working with large datasets. Downsampling to a lower frequency, such as yearly data, reduces the computational complexity of the analysis, making it more manageable and faster.
# 
# Yearly data can provide a more interpretable summary of trends and patterns, making it easier for stakeholders or decision-makers to understand the overall direction of the time series. 

# Now I will be doing downsampling from months to years (decreasing data points).
# 
# A represents year and frequency
# 
# max is the aggregator function

# In[62]:


df.resample(rule='A').max().tail(5)


# Lets visualize the max Close values of all years
# 
# I will do so by resampling the 'Close' prices using the 'A' rule, which stands for annual (yearly) frequency, then it calculates the maximum ('max') closing price for each year and plots the results in the graph below.
# 
# The display shows the maximum closing prices for each year, providing insights into the annual high points for the 'Close' prices.

# In[63]:


df['Close'].resample(rule='A').max().plot(figsize=(15,5))


# Next I will import functions for autocorrelation and partial autocorrelation plots from the statsmodels library, which I am using to understand the autocorrelation of my time series.

# In[64]:


from statsmodels.graphics.tsaplots import plot_acf, plot_pacf


# In[65]:


data = data.drop_duplicates()


# The following plot will display the correlation between the series data and its lagged values.
# 
# In time series analysis, lagged values refer to the values of a variable at previous time points. Specifically, the term "lag" represents the number of time units by which a variable is shifted backward in time. For instance, a lag of 1 corresponds to shifting the variable by one time step, a lag of 2 corresponds to shifting it by two time steps, and so on.

# ### ACF and PACF Plots

# I will use the statsmodels library to build auto-correlation (ACF) and partial auto-correlation plots from the differenced series. ACF describes how well the present value of the series is related with its past values while PACF finds correlation of the residuals with the next lag value. These plot can be utilized to determine the AR and MA values. Below plots shows that the ARMA parameter can be (1,2) or (1,1). On this project I will use the ARIMA and GARCH model to determine parameters required using the lowest AIC values.

# I will now plot ACF (Autocorrelation function)

# In[66]:


fig, ax1 = plt.subplots(figsize=(12, 4))
plot_acf(df['Close'], lags=40, ax=ax1)
ax1.set_title('Autocorrelation Function (ACF) for S&P 500')
plt.show()


# The next plot shows the partial correlation, highlighting the direct relationship between the observation at the current time step and its lagged values.

# I will now plot the PACF (Partial Autocorrelation Function) to understand the correlation between the time series and kag values.

# In[67]:


fig, ax2 = plt.subplots(figsize=(12, 4))
plot_pacf(df['Close'], lags=40, ax=ax2)
ax2.set_title('Partial Autocorrelation Function (PACF) for S&P 500')
plt.show()


# ### Technical Indicators
# 
# Stock market trading technical indicators are mathematical calculations or visual representations derived from the historical price, volume, or open interest of a security. Traders use these indicators to make informed decisions about buying or selling financial instruments. Technical analysis relies on the assumption that historical price movements and trading volumes can provide insights into future price movements. Here are some common technical indicators and their uses:
# 
# 
# Moving Averages: Simple Moving Average (SMA): The SMA calculates the average price over a specified period. Traders use it to identify trends and smooth out price fluctuations.
# 
# Exponential Moving Average (EMA): Similar to SMA, EMA gives more weight to recent prices. It reacts faster to price changes than the SMA.
# 
# Relative Strength Index (RSI): RSI measures the speed and change of price movements. It ranges from 0 to 100 and is used to identify overbought or oversold conditions. A high RSI suggests overbought conditions, while a low RSI suggests oversold conditions.
# 
# Moving Average Convergence Divergence (MACD): MACD is a trend-following momentum indicator that shows the relationship between two moving averages of a security’s price. Traders use it to identify potential buy or sell signals.
# 
# Bollinger Bands: Bollinger Bands consist of a middle band (SMA) and two outer bands that represent standard deviations. They help traders identify volatility and potential reversal points.
# 
# Stochastic Oscillator: The Stochastic Oscillator measures the location of the closing price relative to the high-low range over a set period. It helps identify overbought or oversold conditions.
# 
# Average True Range (ATR): ATR measures market volatility. Traders use it to set stop-loss levels, as a higher ATR suggests higher volatility.
# 
# Ichimoku Cloud: The Ichimoku Cloud consists of multiple lines that help identify trends, support and resistance levels, and potential trend reversals.
# 
# Fibonacci Retracement: Fibonacci retracement levels are horizontal lines indicating where support and resistance are likely to occur. Traders use them to identify potential reversal points.
# 
# Volume Indicators: On-Balance Volume (OBV): OBV measures buying and selling pressure based on volume. Rising OBV suggests buying pressure, while falling OBV suggests selling pressure.
# 
# Volume Profile: It displays the trading activity at various price levels, helping identify where significant buying or selling has occurred.
# 
# Parabolic SAR: The Parabolic SAR is a trend-following indicator that provides potential reversal points. It appears as dots above or below the price chart.
# 
# Williams %R: Williams %R measures overbought or oversold conditions. It ranges from -100 to 0, with readings above -20 indicating overbought conditions and readings below -80 indicating oversold conditions.
# 
# These technical indicators are tools that traders use to analyze price movements, identify trends, and make informed decisions. However, it's important to note that no single indicator guarantees success in trading, and traders often use a combination of indicators to form a comprehensive analysis. Additionally, technical analysis is just one approach to trading, and many investors also consider fundamental analysis and market sentiment in their decision-making process.

# #### Simple Moving Average
# 
# Simple Moving Average is one of the most common technical indicators.
# 
# SMA calculates the average of prices over a given interval of time and is used to determine the trend of the stock.
# 
# As defined above, I will create a slow SMA (SMA_15) and a fast SMA (SMA_5).
# 
# These numerical values represents the time interval of 15 days.

# In[68]:


df['SMA_5'] = df['Close'].rolling(5).mean().shift()
df['SMA_15'] = df['Close'].rolling(15).mean().shift()

fig = go.Figure()
fig.add_trace(go.Scatter(x=df.Date,y=df.SMA_5,name='SMA_5'))
fig.add_trace(go.Scatter(x=df.Date,y=df.SMA_15,name='SMA_15'))
fig.add_trace(go.Scatter(x=df.Date,y=df.Close,name='Close', opacity=0.3))
fig.show()


# #### Exponential Moving Average (EMA)
# 
# An exponential moving average (EMA) is a type of moving average (MA) that places a greater weight and significance on the most recent data points.
# 
# Basically what it means is that the newer stock price data has a higher weightage/significance on the price than older days.

# In[ ]:


df['EMA_5'] = df['Close'].ewm(5).mean().shift()
df['EMA_15'] = df['Close'].ewm(15).mean().shift()

fig = go.Figure()
fig.add_trace(go.Scatter(x=df.Date,y=df.EMA_5,name='EMA_5'))
fig.add_trace(go.Scatter(x=df.Date,y=df.EMA_15,name='EMA_15'))
fig.add_trace(go.Scatter(x=df.Date,y=df.Close,name='Close', opacity=0.3))
fig.show()


# I will now compaire SMA's and EMA's

# In[ ]:


fig = go.Figure()
fig.add_trace(go.Scatter(x=df.Date,y=df.SMA_5,name='SMA_5'))
fig.add_trace(go.Scatter(x=df.Date,y=df.EMA_5,name='EMA_5'))
fig.add_trace(go.Scatter(x=df.Date,y=df.Close,name='Close', opacity=0.3))
fig.show()


# We can see that SMA_5 is performing better as it is closer to Closing price of stock

# #### Moving Average Convergence Divergence (MACD)
# 
# The Moving Average Convergence Divergence (MACD) is a popular momentum and trend-following indicator used in technical analysis, especially in the context of stock market analysis. Developed by Gerald Appel, MACD helps traders identify potential changes in the strength, direction, momentum, and duration of a trend in a stock's price.
# 
# MACD uses two exponentially moving averages and creates a trend analysis based on their convergence or divergence.
# 
# The most commonly used MACD slow and fast signals are based on 26 days and 12 days respectively.
# 
# The MACD is calculated by subtracting the 26-period exponential moving average (EMA) from the 12-period EMA.
# 
# Similar to RSI, MACD triggers technical signals when it crosses above (to buy) or below (to sell) its signal line.
# 
# Here's an explanation of the key components and concepts related to the Moving Average Convergence Divergence (MACD):
# 
# Calculation:
# 
# The MACD is calculated by subtracting the 26-period Exponential Moving Average (EMA) from the 12-period EMA.
# 
# MACDLine = 12 − dayEMA − 26 − day EMA
# 
# Signal Line:
# 
# The Signal Line is a 9-day EMA of the MACD Line.
# 
# SignalLine = 9 − dayEMA of MACD Line
# 
# Histogram:
# 
# The Histogram is the difference between the MACD Line and the Signal Line.
# 
# Histogram = MACD Line − Signal Line
# 
# Interpretation:
# 
# Positive MACD values suggest that the short-term EMA is above the long-term EMA, indicating bullish momentum.
# 
# Negative MACD values suggest that the short-term EMA is below the long-term EMA, indicating bearish momentum.
# 
# Crossovers between the MACD Line and the Signal Line are considered potential buy or sell signals:
# 
# Bullish Crossover (Buy Signal): When the MACD Line crosses above the Signal Line.
# 
# Bearish Crossover (Sell Signal): When the MACD Line crosses below the Signal Line.
# 
# Divergence: Divergence between the MACD and the price of a security can signal potential trend reversals. For example, if the price is making new highs, but the MACD is not confirming with new highs, it may suggest weakening bullish momentum.
# Histogram Peaks and Troughs:
# 
# Peaks and troughs in the histogram represent the difference between the MACD Line and the Signal Line. Larger histogram bars indicate stronger momentum:
# 
# Zero Line Crossings: When the MACD Line crosses above the zero line, it suggests that the short-term EMA is above the long-term EMA, signaling potential bullish momentum.
# When the MACD Line crosses below the zero line, it suggests that the short-term EMA is below the long-term EMA, signaling potential bearish momentum.
# 
# Signal Line Crossovers: The Signal Line crossing above the MACD Line is a bearish signal, indicating a potential reversal to the downside.
# The Signal Line crossing below the MACD Line is a bullish signal, indicating a potential reversal to the upside.
# Traders often use MACD in conjunction with other technical indicators and analysis methods to make more informed trading decisions. 

# In[ ]:


df['EMA_12'] = pd.Series(df['Close'].ewm(span=12).mean())
df['EMA_26'] = pd.Series(df['Close'].ewm(span=26).mean())
df['MACD'] = pd.Series(df['EMA_12'] - df['EMA_26'])
df['MACD_signal'] = pd.Series(df.MACD.ewm(span=9,min_periods=9).mean())

fig = go.Figure()
fig.add_trace(go.Scatter(x=df.Date,y=df.MACD,name='MACD'))
fig.add_trace(go.Scatter(x=df.Date,y=df.MACD_signal,name='MACD_signal'))
fig.show()


# ### Descriptive Analysis of the Time Series Data
# 
# Describing the time series using statistical and employing python libraries is essential part of the analysis. Using these techniques will determine patterns and tests that will help me select the appropriate algorithm and hyper parameters for the algorithm.The most common test are the statsmodel's Augmented Dickey-Fuller Test and the seasonal decompose. Basically, Dickey-Fuller Test it’s the unit-root which is applicable when performing null-hypothesis test (Harris,R.I, 1992).
# 
# #### Augmented Dickey-Fuller Test
# 
# Augmented Dickey Fuller test (ADF Test) is a common statistical test used to test whether a given Time series is stationary or not. It is one of the most commonly used statistical test when it comes to analyzing the stationary of a series (Prabhakaran, 2019).
# 
# Stationarity is a key assumption in many time series models, and deviations from stationarity can impact the reliability and interpretability of your analyses. Here are some reasons why it's crucial to assess stationarity in a time series:
# 
# Modeling Assumption:
# Many time series models assume stationarity, meaning that the statistical properties of the series do not change over time. Examples of such models include Autoregressive Integrated Moving Average (ARIMA) and Seasonal Decomposition of Time Series (STL). If the time series is not stationary, the model assumptions may be violated, leading to inaccurate predictions.
# 
# Forecasting Accuracy:
# Stationary time series are generally easier to model and forecast. When a time series is stationary, its statistical properties, such as mean and variance, remain constant over time. This stability simplifies the forecasting process and increases the reliability of predictions.
# 
# Interpretability:
# Stationary time series are more interpretable. When the statistical properties of a series are consistent over time, it becomes easier to identify trends, patterns, and anomalies. Interpretability is essential for making informed decisions based on the analysis of time series data.
# 
# Statistical Tests:
# Various statistical tests are available to check for stationarity, such as the Augmented Dickey-Fuller (ADF) test and the Kwiatkowski-Phillips-Schmidt-Shin (KPSS) test. These tests provide formal ways to assess whether a time series is stationary or exhibits trends and cycles.
# Mean Reversion:
# 
# In finance and trading, stationarity is often desirable because it implies mean reversion. Mean-reverting time series tend to move back toward their average or equilibrium level over time. This property is exploited in various trading strategies.
# 
# Risk Management:
# Understanding the stationarity of a time series is crucial in risk management. Non-stationary time series may exhibit unpredictable behavior, making risk assessment more challenging. Identifying stationarity helps in better risk modeling and management.
# 
# Seasonal Adjustment:
# Stationarity is a prerequisite for accurately detecting and modeling seasonality. Seasonal adjustment is essential in many applications, such as economic forecasting or analyzing sales data.
# 
# Avoiding Spurious Correlations:
# Non-stationary time series may lead to spurious correlations between variables, which can be misleading. Stationarity helps avoid such correlations by ensuring that relationships observed in the data are not due to changing statistical properties.
# 
# Strong stationarity: is a stochastic process whose unconditional joint probability distribution does not change when shifted in time. Consequently, parameters such as mean and variance also do not change over time.
# 
# Weak stationarity: is a process where mean, variance, autocorrelation are constant throughout the time
# Stationarity is important as non-stationary series that depend on time have too many parameters to account for when modelling the time series. diff() method can easily convert a non-stationary series to a stationary series.
# 
# First, I will check if a series is stationary or not because time series analysis only works with stationary data.
# 
# The Dickey-Fuller test is one of the most popular statistical tests.
# 
# It can be used to determine the presence of unit root in the series, and hence help me understand if the series is stationary or not. The null and alternate hypothesis of this test is:
# 
# #### Null Hypothesis: The series has a unit root (value of a =1)
# 
# ##### Alternate Hypothesis: The series has no unit root.
# 
# If I fail to reject the null hypothesis, I can say that the series is non-stationary. This means that the series can be linear or difference stationary.
# 
# If both mean and standard deviation are flat lines(constant mean and constant variance), the series becomes stationary.

# In[ ]:


def test_stationarity(timeseries):
    
    rolmean = timeseries.rolling(12).mean()
    rolstd = timeseries.rolling(12).std()
    
    plt.figure(figsize=(15,5))
    plt.plot(timeseries,color='blue',label='Original')
    plt.plot(rolmean,color='red',label='Rolling Mean')
    plt.plot(rolstd, color='black', label = 'Rolling Std')
    plt.legend(loc='best')
    plt.title('Rolling Mean and Standard Deviation')
    plt.show(block=False)
    
    print("Results of dickey fuller test")
    adft = adfuller(timeseries,autolag='AIC')
   
    output = pd.Series(adft[0:4],index=['Test Statistics','p-value','No. of lags used','Number of observations used'])
    print(output)

test_stationarity(df['Close'])    


# In[ ]:


print('Augmented Dickey-Fuller Test on Daily Closes')
test = adfuller(df['Close'],autolag='AIC')
out = pd.Series(test[0:4],index=['ADF test statistic','p-value','# lags used','# observations'])

for key,val in test[4].items():
    out[f'critical value ({key})']=val
print(out)


# From the above graph and results, I can see the increasing mean and standard deviation and hence the series is not stationary.
# 
# I see that the p-value is greater than 0.05 therefore I cannot reject the Null hypothesis. Also, the test statistics is greater than the critical values, so the data is non-stationary.

# ### Decomposing the Time Series - Plot the Trend, Seasonality and Residual

# #### Time Series Decomposition
# 
# Time series decomposition is a statistical technique used to break down a time series into its underlying components, revealing the different patterns and trends that contribute to the overall series. The decomposition typically involves separating a time series into three main components: trend, seasonality, and residual (or error). This process helps analysts understand the underlying structure of the data and can be useful for forecasting and analysis.
# 
# The three main components of time series decomposition are:
# 
# Trend: The trend component represents the long-term movement or direction in the data. It captures the overall pattern and direction of the series over an extended period.
# Trends can be upward, downward, or flat. Identifying the trend helps analysts understand the underlying growth or decline in the time series.
# 
# Seasonality:
# Seasonality refers to the repeating patterns or cycles in the data that occur with a fixed frequency. These cycles can be daily, weekly, monthly, quarterly, or any other regular interval.
# Seasonal patterns often correspond to external factors such as weather, holidays, or other recurring events. Identifying seasonality is crucial for understanding when certain patterns are likely to occur.
# 
# Residual (Error):
# The residual, also known as the error or noise, represents the random fluctuations or variability in the data that cannot be attributed to the trend or seasonality.
# Residuals are what remain after the trend and seasonality have been removed from the original time series. Analyzing residuals helps assess the quality of the decomposition and identify any remaining patterns that may need further investigation.
# The decomposition process can be performed using various methods, and one common approach is the additive decomposition model.
# 
# In the additive model, the observed time series (Y) is decomposed into the sum of its trend (T), seasonality (S), and residual (R) components:
# 
# Y(t)=T(t)+S(t)+R(t)
# 
# Alternatively, a multiplicative decomposition model may be used, where the components are multiplied instead of added:
# 
# Y(t)=T(t)×S(t)×R(t)

# Decomposition plots are used to describe the time series trend and seasonal factors. The main objective of this procedure is to estimate seasonal effect that can be used to create and present seasonally adjusted values. A seasonal adjusted value deducts the effect of the seasonality from the main signal so that the trend can be seen clearly (Penn State University, 2022).

# The next command will store the results for seasonal decomposition using seasonal_decompose()

# In[ ]:


decompose_result = seasonal_decompose(df['Close'],model = 'add',period = 12)


# The frequency of my next plot is Daily

# In[ ]:


fig, axes = plt.subplots(4, 1, sharex=True)
fig.set_size_inches((10,8))
fig.tight_layout() 
fig.set_facecolor('#bdbfc0')

decompose_result.observed.plot(ax=axes[0], legend=False, color='r')
axes[0].set_ylabel('Observed');
decompose_result.trend.plot(ax=axes[1], legend=False, color='g')
axes[1].set_ylabel('Trend');
decompose_result.seasonal.plot(ax=axes[2], legend=False)
axes[2].set_ylabel('Seasonal');
decompose_result.resid.plot(ax=axes[3], legend=False, color='k')
axes[3].set_ylabel('Residual');
plt.show()


# Findings:
# 
# It is confirmed that my time series shows trend going up around 1990 with several prominent downfalls. My data is not stationary.

# ### Differencing - Make the Series Stationary
# 
# Differencing is one method of dealing with non stationary data, this process make such series stationary. In practice, it means subtracting subsequent observations from one another (Lewinson, 2020). Most of statistical forecasting methods derived from the assumption that the time series can be extracted nearly stationary with the use of mathematical transformations such as differencing, this will make the prediction to be easy because the the statistical property of the series will be the same in the future as they in the past (Nau, 2019).
# 
# Differencing can help stabilise the mean of a time series by removing changes in the level of a time series, and therefore eliminating (or reducing) trend and seasonality.
# 
# Differencing shifts ONE/MORE row towards downwards.

# In[ ]:


df['Stocks First Difference']=df['Close']-df['Close'].shift(1)
df['Stocks Seasonal Difference']=df['Close']-df['Close'].shift(12)
df['Stocks Seasonal+Daily Difference']=df['Stocks Seasonal Difference']-df['Stocks Seasonal Difference'].shift(1)


# In[ ]:


adft = adfuller(df['Stocks First Difference'].dropna(),autolag='AIC')
output = pd.Series(adft[0:4],index=['Test Statistics','p-value','No. of lags used','Number of observations used'])
print(output)


# In[ ]:


adft = adfuller(df['Stocks Seasonal Difference'].dropna(),autolag='AIC')
output = pd.Series(adft[0:4],index=['Test Statistics','p-value','No. of lags used','Number of observations used'])
print(output)


# In[81]:


adft = adfuller(df['Stocks Seasonal+Daily Difference'].dropna(),autolag='AIC')
output = pd.Series(adft[0:4],index=['Test Statistics','p-value','No. of lags used','Number of observations used'])
print(output)


# Findings:
# 
# The p values is less than 0.05, we can reject the null hypothesis and assume that the our time series is stationary

# #### Plotting the First Difference Values
# 
# Plotting the first difference will transform my data making it more suitable for modelling, and reveal important patterns not present in the raw data.

# In[82]:


df['Stocks First Difference'].plot()


# To visualize and analyze financial my data, a Python script was developed to create informative line plots using the Plotly library. The code snippet below demonstrates how these plots were generated and customized:

# In[83]:


fig = px.line(df, y='Stocks First Difference',width=900, height=700)
fig.update_traces(line_color="#0c8f8f")

m = dict(
    l = 10,
    r = 10,
    b= 80,
    t = 80,
    pad = 30)
    

fig.update_layout(margin=m,paper_bgcolor="#bdbfc0")
fig.update_yaxes(title_text='<b>Closes</b>', row=1, 
                 col=1,tickfont_size=10,titlefont = dict(size = 14))
fig.update_xaxes(title_text='<b>Date</b>', row=1, 
                 col=1,tickfont_size=10,titlefont = dict(size = 14))
    
fig.show()


# This script allows for the creation of visually appealing and informative line plots. It provides flexibility in customizing the plot's appearance, including line colors, margins, background color, and axis labels. The resulting visualizations aid in the analysis of financial trends and patterns, contributing to a comprehensive understanding of the data.
# 
# 

# ### ACF and PACF Plots
# 
# I will use the statsmodels library to build auto-correlation (ACF) and partial auto-correlation plots from the differenced series. ACF describes how well the present value of the series is related with its past values while PACF finds correlation of the residuals with the next lag value. These plot can be utilized to determine the AR and MA values. Below plots shows that the ARMA parameter can be (1,2) or (1,1). For my capstone project I will use the auto arima and SARIMAX algorithm to determine parameters required using the lowest AIC values.
# 
# Autocorrelation - The autocorrelation function (ACF) measures how a series is correlated with itself at different lags.
# 
# Partial Autocorrelation - The partial autocorrelation function can be interpreted as a regression of the series against its past lags. The terms can be interpreted the same way as a standard linear regression, that is the contribution of a change in that particular lag while holding others constant.

# In[84]:


import statsmodels.api as sm
fig = plt.figure(figsize = (10, 4))
ax1 = fig.add_subplot(211)
fig = sm.graphics.tsa.plot_acf(df['Close'].dropna(),lags = 20,ax = ax1,)
ax2 = fig.add_subplot(212)
fig = sm.graphics.tsa.plot_pacf(df['Close'].dropna(),lags = 20,ax = ax2,)
fig.tight_layout()


# As all lags are either close to 1 or at least greater than the confidence interval, they are statistically significant.

# I will now plot the Stocks First Difference

# In[85]:


plot_acf(df["Stocks First Difference"].dropna(),lags=5,title="AutoCorrelation")
plt.show()


# The diverging blue region is the confidence interval

# I will now plot the Stocks Seasonal Difference

# In[86]:


plot_acf(df["Stocks Seasonal Difference"].dropna(),lags=15,title="AutoCorrelation")
plt.show()


# I will now plot the Stocks Seasonal + Daily Difference

# In[87]:


plot_acf(df["Stocks Seasonal+Daily Difference"].dropna(),lags=10,title="AutoCorrelation")
plt.show()


# #### Lets now analyse the Partial Auto Correlation 
# 
# Only 0 and 1 are statistically significant

# In[88]:


plot_pacf(df["Stocks First Difference"].dropna(),lags=5,title="Partial AutoCorrelation")
plt.show()


# In[89]:


plot_pacf(df["Stocks Seasonal Difference"].dropna(),lags=15,title="Partial AutoCorrelation")
plt.show()


# In[90]:


plot_pacf(df["Stocks Seasonal+Daily Difference"].dropna(),lags=10,title="Partial AutoCorrelation")
plt.show()


# This plots display the p and q values.
# 
# Partial Auto Correlation is for p-value while Auto Correlation is for q value.

# ### Time Series Forecasting
# 
# Time series forecasting occurs when you make scientific predictions based on historical time stamped data. It involves building models through historical analysis and using them to make observations and drive future strategic decision-making. An important distinction in forecasting is that at the time of the work, the future outcome is completely unavailable and can only be estimated through careful analysis and evidence-based priors.
# 
# Time series forecasting is the process of analyzing time series data using statistics and modeling to make predictions and inform strategic decision-making. It’s not always an exact prediction, and likelihood of forecasts can vary wildly—especially when dealing with the commonly fluctuating variables in time series data as well as factors outside our control. However, forecasting insight about which outcomes are more likely—or less likely—to occur than other potential outcomes. Often, the more comprehensive the data we have, the more accurate the forecasts can be. While forecasting and “prediction” generally mean the same thing, there is a notable distinction. In some industries, forecasting might refer to data at a specific future point in time, while prediction refers to future data in general. Series forecasting is often used in conjunction with time series analysis. Time series analysis involves developing models to gain an understanding of the data to understand the underlying causes. Analysis can provide the “why” behind the outcomes you are seeing. Forecasting then takes the next step of what to do with that knowledge and the predictable extrapolations of what might happen in the future.
# 

# #### Split the data

# To measure the performance of the forecasting model, I would ideally want to split the time series into a training period and a validation period. This is called fixed partitioning.

# Here, we we will opt for a hold-out based validation.
# 
# Now we are going to create an ARIMA model and will train it with the closing price of the stock on the train data. So let us split the data into train and test set and visualize it.
# 
# train: Data from 1950 (the first stock market trading) to 31st December, 2021.
# valid: Data from 1st January, 2022 to 2023.

# In[91]:


stocks_data=stocks_data[stocks_data.Date > "2015"]
df_train = stocks_data[stocks_data.Date < "2019"]
df_valid = stocks_data[stocks_data.Date >= "2019"]


# ### Rolling ARIMA

# In[92]:


train = df_train['Close'].values
test = df_valid['Close'].values


# I will use Walk forward validation which is a time series cross-validation technique used to assess the performance of a forecasting model. In this validation approach, the model is trained on a training dataset, and then predictions are made for a test dataset. However, instead of using a fixed split between training and testing sets, the training set is gradually expanded, and predictions are made sequentially for each step.

# In[93]:


history = [x for x in train]
predictions = list()

for t in range(len(df_valid)):
    model = ARIMA(history, order=(3,1,3))
    model_fit = model.fit()
    output = model_fit.forecast()
    yhat = output[0]
    predictions.append(yhat)
    obs = test[t]
    history.append(obs)


# #### Mean square error
# 
# Mean square error or mean square deviation is one of the most commonly used measures for evaluating the quality of predictions. It shows how far predictions fall from measured true values using Euclidean distance.
# 
# Next function will evaluate forecasts, I will use the common number of samples to calculate the MSE or the first 168 samples from both test and predictions arrays. 

# In[94]:


common_samples = min(len(test), len(predictions))
test = test[:common_samples]
predictions = predictions[:common_samples]

rolling_mse = mean_squared_error(test, predictions)
print('Test MSE: %.3f' % rolling_mse)


# Th following code will generate a Plotly line chart with two lines: one for historical closing prices ('Close') and another for the forecasted values ('Forecast_Rolling_ARIMA'). You can visualize how well the rolling ARIMA model's forecasts align with the actual closing prices.

# In[95]:


fig = go.Figure()
fig.add_trace(go.Scatter(x=df_valid.Date,y=df_valid.Close,name='Close'))
fig.add_trace(go.Scatter(x=df_valid.Date,y=predictions,name='Forecast_Rolling_ARIMA'))
fig.show()


# ### ARIMA
# 
# The following code defines two functions, difference and inverse_difference, which are commonly used in time series analysis, especially when working with differenced or transformed data.
# 
# difference(dataset, interval=1): calculates the difference between values in a time series dataset. It takes the following parameters:
# 
# dataset: The original time series data (1D array or list).
# interval: The time interval for differencing. By default, it's set to 1, which means you're computing the first-order differences (i.e., the difference between each value and the previous one).
# 
# The inverse_difference(history, yhat, interval=1): performs the inverse operation of differencing. It takes the following parameters:
# 
# history: The historical values of the time series (1D array or list).
# yhat: The differenced (forecasted) value that you want to transform back to the original scale.
# interval: The time interval used for differencing, which should match the interval used in the difference function. By default, it's set to 1.
# The function adds the differenced value yhat to the last value in the history array, effectively reversing the differencing operation.
# 
# These functions are useful when working with differenced time series data, such as when applying differencing to make a non-stationary time series stationary, model it, and then need to transform the forecasts back to the original scale. The difference function calculates differences, and the inverse_difference function undoes those differences to obtain the original values.

# In[96]:


def difference(dataset, interval=1):
    diff = list()
    for i in range(interval, len(dataset)):
        value = dataset[i] - dataset[i-interval]
        diff.append(value)
    return np.array(diff)

def inverse_difference(history, yhat, interval=1):
    return yhat + history[-interval]


# #### Trend Differencing by using Daily Lag
# 
# The following code contain the forecasted values for my test data based on the ARIMA model I've fitted to the differenced training data. I can then use these forecasts for evaluation and analysis.

# In[97]:


differenced = difference(train)
model=ARIMA(differenced,order=(2,1,2))
model_fit=model.fit()
start=len(train)
end=len(train)+len(test)-1
forecast = model_fit.predict(start=start,end=end)


# I will now store predicted results
# 
# The following command predicted_results list will contain all the forecasted values in their original scale, and the history list will have been updated with the forecasted values, making them available for the next forecast. This process allows me to iteratively generate forecasts one step at a time while maintaining the integrity of historical data.

# In[98]:


history = [x for x in train]
predicted_results = list()


for yhat in forecast:
    inverted = inverse_difference(history, yhat)
    history.append(inverted)
    predicted_results.append(inverted)


# The following command will create a plot using the Plotly library to visualize the actual closing prices (Close) and the forecasted results (predicted_results) from the ARIMA model.
# 
# The resulting plot will show both the actual closing prices and the forecasted values on the same graph, allowing me to visually compare the model's predictions to the actual data. This can be helpful in evaluating the performance of the ARIMA model.

# In[99]:


fig = go.Figure()
fig.add_trace(go.Scatter(x=df_valid.Date,y=df_valid.Close,name='Close'))
fig.add_trace(go.Scatter(x=df_valid.Date,y=predicted_results,name='Forecast_ARIMA'))
fig.show()


# I will now calculate the Mean Squared Error between the actual closing prices (y_true_aligned) and the forecasted results (predicted_results_aligned) to assess the performance of time series forecasting models.
# 
# By comparing the forecasted results to the actual closing prices and calculating the MSE, I can assess how well my ARIMA model is performing in terms of prediction accuracy. A lower MSE suggests that the model's predictions are closer to the actual values, while a higher MSE indicates greater prediction errors.

# In[100]:


common_samples = min(len(df_valid['Close']), len(predicted_results))
y_true_aligned = df_valid['Close'][:common_samples]
predicted_results_aligned = predicted_results[:common_samples]

mse_daily = mean_squared_error(y_true_aligned, predicted_results_aligned)
print('Test MSE: %.3f' % mse_daily)


# #### Seasonal differencing using Seasonal lag
# 
# I will modify my code to include a yearly differencing (days_in_year=365) and adjust the ARIMA model parameters accordingly. This is a valid approach, especially when dealing with time series data that exhibits yearly seasonality or long-term trends. 

# In[101]:


days_in_year=365
differenced = difference(train,days_in_year)
model=ARIMA(differenced,order=(10,1,4))
model_fit=model.fit()
start=len(train)
end=len(train)+len(test)-1
forecast = model_fit.predict(start=start,end=end)


# I will store predicted results
# 
# But this time applying an inverse difference transformation with a yearly lag of 365 days. 
# 
# By applying the inverse difference transformation, I will convert the forecasted values back to the original scale of my time series data. This will allow me to make meaningful predictions that can be compared directly with the actual values.
# 
# After running this code, predicted_results should contain the forecasted values in the original scale of my time series data, considering the yearly differencing.

# In[102]:


history = [x for x in train]
predicted_results = list()

for yhat in forecast:
    inverted = inverse_difference(history, yhat, days_in_year)
    history.append(inverted)
    predicted_results.append(inverted)


# The following command  is using the Plotly library to create a line chart that visualizes the actual closing prices (Close) from your validation dataset (df_valid) along with the forecasted results (predicted_results) obtained from your ARIMA model.
# 
# The resulting chart will has two lines: one representing the actual closing prices and another representing the ARIMA model's forecasts.

# In[103]:


fig = go.Figure()
fig.add_trace(go.Scatter(x=df_valid.Date,y=df_valid.Close,name='Close'))
fig.add_trace(go.Scatter(x=df_valid.Date,y=predicted_results,name='Forecast_ARIMA'))
fig.show()


# The followimg code calculates the Mean Squared Error (MSE) between the test data and the predicted results obtained from the ARIMA model. The MSE is a common metric used to evaluate the performance of regression models and time series forecasting models. It measures the average squared difference between the actual (observed) values and the predicted values.

# In[104]:


mse_seasonal = mean_squared_error(test, predicted_results)
print('Test MSE: %.3f' % mse_seasonal)


# #### Seasonal+Daily Differencing
# 
# I will now introduce into my ARIMa model a seasonal differencing component.
# 
# This model incorporates both differencing and seasonal differencing components to account for non-stationarity and seasonality in my time series data. The choice of the order parameters (5,2,5) and seasonal differencing interval (days_in_year) is based on the characteristics of my specific dataset 

# In[105]:


days_in_year=365
differenced_S = difference(train,days_in_year)
differenced = difference(differenced_S)
model=ARIMA(differenced,order=(5,2,5))
model_fit=model.fit()
start=len(train)
end=len(train)+len(test)-1
forecast = model_fit.predict(start=start,end=end)


# I will once again store the predicted results

# In[106]:


history = [x for x in train]
predicted_results = list()
 
interval=366
for yhat in forecast:
    inverted = inverse_difference(history, yhat, interval)
    history.append(inverted)
    predicted_results.append(inverted)


# In[107]:


fig = go.Figure()
fig.add_trace(go.Scatter(x=df_valid.Date,y=df_valid.Close,name='Close'))
fig.add_trace(go.Scatter(x=df_valid.Date,y=predicted_results,name='Forecast_ARIMA'))
fig.show()


# I will test once again Mean Squared Error to evaluate Forecasts

# In[108]:


mse_sd = mean_squared_error(test, predicted_results)
print('Test MSE: %.3f' % mse_sd)


# From the above result, I can Conclude that lowest mse score was achieved by daily differencing.

# In[109]:


best_arima_mse = mse_daily


# ### LSTM

# Long Short-Term Memory (LSTM) networks are a type of recurrent neural network capable of learning order dependence in sequence prediction problems.
# 
# A recurrent network whose inputs are not fixed but rather constitute an input sequence can be used to transform an input sequence into an output sequence while taking into account contextual information in a flexible way.
# 
# Yoshua Bengio, et al., Learning Long-Term Dependencies with Gradient Descent is Difficult, 1994.
# 
# Unfortunately, the range of contextual information that standard RNNs can access is in practice quite limited. The problem is that the influence of a given input on the hidden layer, and therefore on the network output, either decays or blows up exponentially as it cycles around the network’s recurrent connections. This shortcoming … referred to in the literature as the vanishing gradient problem … Long Short-Term Memory (LSTM) is an RNN architecture specifically designed to address the vanishing gradient problem.
# 
# Alex Graves, et al., A Novel Connectionist System for Unconstrained Handwriting Recognition, 2009
# 
# This makes LSTM a deep learning network well suited for time series forecasting.

# I will start by assigning training values, the training process is essential for the model to understand the sequential nature of the data.

# In[110]:


training_values = np.reshape(train,(len(train),1))
scaler = MinMaxScaler()
training_values = scaler.fit_transform(training_values)
x_train = training_values[0:len(training_values)-1]
y_train = training_values[1:len(training_values)]
x_train = np.reshape(x_train,(len(x_train),1,1))


# The following line will follow the following steps: create model, compile the model and train the model.
# 
# I will use Adaptive Moment Estimation (ADAM) as optimizer due to its efficiency and good performance in a wide range of tasks.

# In[111]:


model = Sequential()
model.add(LSTM(128,return_sequences=True,input_shape=(None,1)))
model.add(LSTM(64,return_sequences=False))
model.add(Dense(25))
model.add(Dense(1))

model.compile(optimizer='adam',loss='mean_squared_error')

model.fit(x_train,y_train,epochs=25,batch_size=8)


# After training the LSTM model, I will evaluate its performance on a separate set of data that it hasn't seen during training. This set is commonly referred to as the test set. I will use this set to assess how well my model generalizes to new, unseen data.
# 
# LSTMs expect input data in a specific format, usually a three-dimensional array (samples, time steps, features). Reshaping is necessary to match the input shape that the LSTM layer my model expects. It's crucial to maintain the temporal sequence of my data during reshaping so that the model can learn and make predictions based on the sequential patterns.
# 
# During the preprocessing steps, I will scale my data. Scaling ensures that all features have a similar scale, which can improve the convergence of the training process. The conversion back from the scaler is necessary to obtain predictions in the original scale of my data. This step is important for interpreting and evaluating the model's performance in the context of the original data.

# In[112]:


test_values = np.reshape(test, (len(test), 1))
test_values = scaler.transform(test_values)
test_values = np.reshape(test_values, (len(test_values), 1, 1))
predicted_price = model.predict(test_values)
predicted_price = scaler.inverse_transform(predicted_price)
predicted_price=np.squeeze(predicted_price)


# Next I will create a plot to visualize the actual closing prices and the forecasted prices using an LSTM (Long Short - Term Memory) model.
# 
# My objective is to compare the actual and the forecasted stock prices, providing a clear visualization of how well the LSTM models forecasts align with the real data.  This is a valuable step for evaluating the model's performance and demonstrating its ability to predict stock market price movements.

# In[113]:


fig = go.Figure()
fig.add_trace(go.Scatter(x=df_valid.Date,y=df_valid.Close,name='Close'))
fig.add_trace(go.Scatter(x=df_valid.Date,y=predicted_price,name='Forecast_LSTM'))
fig.show()


# I will now evaluate Mean Squared Error (MSE)

# In[114]:


mse_lstm = mean_squared_error(test, predicted_price)
print('Test MSE: %.3f' % mse_lstm)


# MSE: 4134.940 quantifies the level of error or discrepancy between the predictions made by my model. It serves as a measure of the model's accuracy, with lower values indicating better predictive performance.

# ### Comparing model scores

# The next command will create a DataFrame named MSE with information about the mean squared error (MSE) for three different models: "Rolling ARIMA," "ARIMA," and "LSTM."
# 
# LSTM model appears to be the best-performing model, followed by the ARIMA model, while the "Rolling ARIMA" model performs the worst in terms of predictive accuracy. Lower MSE values indicate better model performance in terms of prediction quality.

# In[115]:


models = ['Rolling ARIMA','ARIMA','LSTM']
lst_acc = [rolling_mse,best_arima_mse,mse_lstm]
MSE = pd.DataFrame({'Model': models, 'Mean Squared Error': lst_acc})
MSE.sort_values(by="Mean Squared Error")


# In[ ]:





# ## Models to Predict Stock Market Crashes

# On this step the main objective is to design of a machine learning algorithm that predicts stock market crashes based on past price information. I used public available market data from seven major stock market indices. This is a classification problem to forecast whether or not a crash will occur within the next 1, 3 or 6 months at any point in time. I trained and tested linear and logistic regression models, support vector machines, decision trees and recurrent neural networks with long short term memory (RNN LSTM).
# 
# Before I use data in a linear model, I will analyse if it correlates with its independent variable.

# ### Find least correlated datasets
# 
# In this section, I select the datasets that will be further explored and will later be used to develop an algorithm that predicts crashes. To avoid overfitting on certain patterns and biased test sets, the datasets used should not have a strong cross correlation.
# 
# The correlation matrix is a square matrix where the diagonal elements are always 1 (because a variable is perfectly correlated with itself) and the off-diagonal elements are between -1 and 1. Positive values indicate a positive correlation, meaning that as one variable increases, the other variable also increases. Negative values indicate a negative correlation, meaning that as one variable increases, the other variable decreases. The closer the correlation coefficient is to 1 or -1, the stronger the correlation.

# In[116]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import gridspec
import os
import seaborn as sns
from pylab import rcParams
from collections import defaultdict
from scipy.optimize import curve_fit
import sys
import warnings
if not sys.warnoptions:
    warnings.simplefilter("ignore")
    
datasets_original = ['^GSPC.txt', '^DJI.txt', '^NDX.txt', '^N225.txt', 'SSE.txt',\
'^HSI.txt', '^BSESN.txt', '^GDAXI.txt', '^SSMI.txt', '^MXX.txt', \
                     '^BVSP.txt']
dataset_names = ['S&P 500', 'DJ', 'NDX', 'N225', 'SSE', 'HSI', 'BSESN', 'DAX', \
                 'SMI', 'MXX', 'BVSP']

datasets = []

for d in datasets_original:
    data_original = pd.read_csv(d, index_col='Date')
    data_original.index = pd.to_datetime(data_original.index, format='%Y/%m/%d')
    data_norm = data_original['Close'] / data_original['Close'][-1]
    data_ch = data_original['Close'].pct_change()
    window = 10
    data_vol = data_original['Close'].pct_change().rolling(window).std()
    data = pd.concat([data_original['Close'], data_norm, data_ch, data_vol], axis=1).dropna()
    data.columns = ['price', 'norm', 'ch', 'vol']
    datasets.append(data)

datasets[5] = datasets[5].loc['1990-11-09':, :]  

df_ch = [d['ch'] for d in datasets]
df_returns = pd.concat(df_ch, axis=1, keys=dataset_names)
corr = df_returns.corr()

print('Correlations of daily returns between datasets (non-correlated datasets):')
ax = sns.heatmap(corr, annot=True, cmap='rocket_r')
plt.show()


# The Correlation matrix shows that the three US indices (S&P, DJ, NDX), the DAX and SMI and the MXX and BVSP are highly correlated. To avoid overfitting when training prediction models, a correlation of > 0.5 for any two datasets should be avoided. Therefore, the SJ, NDX, DAX and MXX will be excluded for further analysis

# In[117]:


datasets_original = ['^GSPC.txt', '^DJI.txt', '^NDX.txt', '^N225.txt', 'SSE.txt',\
'^HSI.txt', '^BSESN.txt', '^GDAXI.txt', '^SSMI.txt', '^MXX.txt', \
                     '^BVSP.txt']
dataset_names = ['S&P 500', 'N225', 'SSE', 'HSI', 'BSESN', 'SMI', 'BVSP']

datasets = []

for d in datasets_original:
    data_original = pd.read_csv(d, index_col='Date')
    data_original.index = pd.to_datetime(data_original.index, format='%Y/%m/%d')
    data_norm = data_original['Close'] / data_original['Close'][-1]
    data_ch = data_original['Close'].pct_change()
    window = 10
    data_vol = data_original['Close'].pct_change().rolling(window).std()
    data = pd.concat([data_original['Close'], data_norm, data_ch, data_vol], axis=1).dropna()
    data.columns = ['price', 'norm', 'ch', 'vol']
    datasets.append(data)

datasets[5] = datasets[5].loc['1990-11-09':, :]  

df_ch = [d['ch'] for d in datasets]
df_returns = pd.concat(df_ch, axis=1, keys=dataset_names)
corr = df_returns.corr()

print('Correlations of daily returns between datasets (non-correlated datasets):')
ax = sns.heatmap(corr, annot=True, cmap='rocket_r')
plt.show()


# The correlation matrix with the remaining datasets shows no correlations among any two datasets of > 0.5
# 
# #### 2. Distribution of prices, daily returns, drawdowns¶

# In[118]:


rcParams['figure.figsize'] = 10, 3
plt_titles = ['S&P since 1950', 'N225 since 1965', 'SSE since 1996', 'HSI since 1987', \
              'BSESN since 1997', 'SMI since 1990', 'BVSP since 2002']
for ds, t in zip(datasets, plt_titles):
    plt.plot(ds['price'], color='blue', linewidth=0.7)
    plt.grid()
    plt.legend(['Price'])
    plt.title(t + ' - Price')
    plt.show()


# The time series plots give an impression of the performance of the different markets over the past 50-20 years.

# In[119]:


for ds, t in zip(datasets, plt_titles):
    plt.plot(ds['ch'], color='blue', linewidth=0.7)
    plt.ylim(-0.2, 0.2)
    plt.grid()
    plt.legend(['Return'])
    plt.title(t + ' - Daily returns')
    plt.show()


# The amplitude of daily returns over time for all datasets give an impression of the volatility in the different markets with the Brazilian market showing the larges daily gains/losses.

# In[120]:


corr_ds = []
rcParams['figure.figsize'] = 10, 5
for ds, t in zip(datasets, plt_titles):
    corr = [1]
    for i in range(1, 7):
        corr.append(np.corrcoef(ds['ch'][i:], ds['ch'][:-i])[0, 1])
    plt.plot(corr)
plt.title('All data sets - Correlation of daily returns')
plt.legend(dataset_names)
plt.xlabel('Lag (days)')
plt.ylabel('Correlation')
plt.grid()
plt.show()


# The autocorrelation of daily returns is close to zero for a lag > 1 day, indicating that the daily return is not a strong predictor for the price change of the following day.

# In[121]:


rcParams['figure.figsize'] = 10, 3
for ds, t in zip(datasets, plt_titles):
    plt.hist(ds['ch'], bins=200, rwidth=1, alpha=0.75)
    plt.xlim(-0.2, 0.2)
    plt.title(t + ' - all daily returns')
    plt.grid()
    plt.show()


# The histograms for daily return distributions show that the vast majority of returns lies between -0.05 and 0.05 for all datasets. The absolute values of extreme daily gains or losses are larger than 0.1. A visual comparison between the datasets shows that the SSE and BVSP have "fat tails" indicating a realtively high volatility with a large amount of high one day gains/large one day losses.

# In[122]:


for ds, t in zip(datasets, plt_titles):
    max_return = max(abs(ds['ch']))
    m = round(max_return+0.01,2)
    bins = np.linspace(-m, m, 2000)
    d = {}
    for i in range(1, len(bins)+1):
        d[i] = bins[i-1]
    disc = np.digitize(x=ds['ch'], bins=bins)
    d1 = defaultdict(int)
    for i in disc:
        d1[d[i]] += 1
    df = pd.DataFrame(list(d1.items()))
    df.columns = ['return', 'n']
    df_neg = df[df['return']<0]
    df_neg = df_neg.sort_values(by='return', ascending=True).reset_index(drop=True)
    plt.scatter(df_neg['return'], df_neg['n'], s=30, color='red')
    plt.yscale('log')
    df_neg_reg = df_neg[df_neg['return']>-0.05]
    m, c = np.polyfit(df_neg_reg['return'], np.log(df_neg_reg['n']), 1)
    y_fit = np.exp(m*df_neg['return'] + c)
    plt.ylim(bottom=10**0)
    df_pos = df[df['return']>0]
    df_pos = df_pos.sort_values(by='return', ascending=False).reset_index(drop=True)
    plt.scatter(df_pos['return'], df_pos['n'], s=20, color='green')
    plt.yscale('log')
    df_pos_reg = df_pos[df_pos['return']<0.05]
    m, c = np.polyfit(df_pos_reg['return'], np.log(df_pos_reg['n']), 1)
    y_fit = np.exp(m*df_pos['return'] + c)
    plt.ylim(bottom=10**-0.1)
    plt.xlim(-0.3, 0.3)
    plt.title(t + ' - distribution of daily returns')
    plt.xlabel('Return')
    plt.ylabel('Frequency (log)')
    plt.grid()
    plt.show()
    plt.show()


# The frequency distribution plots show that extreme positive (red) and negtive (green) returns occur on rare instances. Extreme negative daily returns of ~0.1 and more likely contribute to a crash.
# 
# #### Drawdowns
# To detect crashes, the drawdowns are calculated. A drawdown is a total loss over consequtive days from the last maximum to the nex minimum of the price. A drawdown occuring over n days (the period from t_1 to t_n) is described as d = (p_max - p_min)/pmax, with p_max = p(t_1) > p(t_2) > ... > p(t_n) = p_min.

# In[123]:


dd_df = []
for ds in datasets:
    pmin_pmax = (ds['price'].diff(-1) > 0).astype(int).diff() #<- -1 indicates pmin, +1 indicates pmax
    pmax = pmin_pmax[pmin_pmax == 1]
    pmin = pmin_pmax[pmin_pmax == -1]
    if pmin.index[0] < pmax.index[0]:
        pmin = pmin.drop(pmin.index[0])
    if pmin.index[-1] < pmax.index[-1]:
        pmax = pmax.drop(pmax.index[-1])
    dd = (np.array(ds['price'][pmin.index]) - np.array(ds['price'][pmax.index])) \
        / np.array(ds['price'][pmax.index])
    dur = [np.busday_count(p1.date(), p2.date()) for p1, p2 in zip(pmax.index, pmin.index)]
    d = {'Date':pmax.index, 'drawdown':dd, 'd_start': pmax.index, 'd_end': pmin.index, \
         'duration': dur}    
    df_d = pd.DataFrame(d).set_index('Date')
    df_d.index = pd.to_datetime(df_d.index, format='%Y/%m/%d')
    df_d = df_d.sort_values(by='drawdown')
    df_d['rank'] = list(range(1,df_d.shape[0]+1))
    dd_df.append(df_d)

l_dict_dd = []
for dd, t in zip(dd_df, plt_titles):
    max_dd = max(abs(dd['drawdown']))
    m = round(max_dd+0.01,2)
    bins = np.linspace(-m, m, 800)
    d = {}
    for i in range(1, len(bins)+1):
        d[i] = bins[i-1]
    disc = np.digitize(x=dd['drawdown'], bins=bins)
    d1 = defaultdict(int)
    for i in disc:
        d1[d[i]] += 1
    l_dict_dd.append(d1)
    plt.bar(x=dd['duration'].value_counts().index, height=dd['duration'].\
        value_counts()/dd['duration'].shape[0], color='red', alpha=0.6)
    plt.xticks(dd['duration'].value_counts().index)
    plt.title(t + ' - Duration of drawdowns')
    plt.xlabel('Duration (number of days)')
    plt.grid()
    plt.show()


# The duration of drawdown histograms show how long drawdowns typically last. For all datasets ~50% of all drawdowns last only one day, meaning that a price decrease from the previous to the current day is followed by a price increase on the next following day. This confirms the low autocorrelation identified earlier. The longest drawdowns last around 10-12 business days. However, the longest drawdwons are not necessasary responsible for the highest losses which will be apparent when we identify crashes.

# In[124]:


rcParams['figure.figsize'] = 10, 4.5
for d1, t in zip(l_dict_dd, plt_titles):
    df_d_bins = pd.DataFrame(list(d1.items()))
    df_d_bins.columns = ['drawdown', 'n']
    plt.scatter(df_d_bins['drawdown'], df_d_bins['n'], s=40, color='red', alpha=0.6)
    plt.yscale('log')
    df_d_bins_reg = df_d_bins[df_d_bins['drawdown']>-0.08]
    m, c = np.polyfit(df_d_bins_reg['drawdown'], np.log(df_d_bins_reg['n']), 1)
    y_fit = np.exp(m*df_d_bins['drawdown'] + c)
    plt.ylim(bottom=10**-.1)
    plt.title(t + ' - Frequency all drawdowns')
    plt.xlabel('Drawdown loss')
    plt.ylabel('Freqyency (log)')
    plt.grid()
    plt.show()


# The frequency distribution plot of drawdowns shows that extreme drawdowns (> ~15%) occur on rare instances. While such large drawdowns only occured two times over nearly 70 years in the S&P, they occur much more frequently in the Indian (BSESN) or Brazilian (BVSP) market. These extreme events are associated with crashes. Under 3. we will introduce two different methods for rules to set a threshold for drawdowns that identifies crashes.

# In[125]:


for dd, t in zip(dd_df, plt_titles):
    plt.scatter(dd['rank'], abs(dd['drawdown']), s=10*dd['duration'], alpha=0.5,\
                color='red')
    plt.xscale('log')
    plt.title(t + ' - Rank ordering of all drawdowns')
    plt.xlabel('Drawdown rank (log)')
    plt.ylabel('Loss')
    plt.grid()
    plt.show()


# For rank ordering plots above, the drawdwons have been ranked from 1 (largest drawdown in dataset) to n. The size of each bubble corresponds to the duration of each drawdown and show that the largest drawdowns are not necessarily the longest ones. These plots provide further visual evidence of the existence of outliers as drawdowns that are larger than expected.

# In[126]:


def weibull(x, chi, z):
    return np.exp(-abs(x/chi)**z)

for dd, t in zip(dd_df, plt_titles):
    x = dd['drawdown']
    y = dd['rank']/dd['rank'].max()
    init_vals = [0.9, 0.015] 
    best_vals, covar = curve_fit(weibull, abs(x), y, p0=init_vals)
    chi = best_vals[0]
    z = best_vals[1]
    plt.scatter(abs(x), y, s=10*dd['duration'], alpha=0.5, color='red')
    y_fit = [weibull(abs(xi), chi, z) for xi in x]
    plt.plot(abs(x), y_fit, color='black', ls='dashed')
    plt.yscale('log')
    plt.ylim(bottom=10**-4)
    plt.legend(['Drawdowns', 'Weibull fit'])
    plt.title(t + ' - fit Weibull distribution to drawdowns')
    plt.xlabel('Drawdown loss')
    plt.ylabel('Drawdown rank (log, normalized)')
    plt.grid()
    plt.show()


# The Weibull exponential model: y ~ exp(-abs(x/chi)^z) has been used by Johansen and Sornette (2001) to fit the distributions of drawdowns by rank. As we weill discuss below, large deviations from the Weibull distribution are considered to be crashes.
# 
# #### Identify Crashes
# First methodology: crashes as the 99.5% empirical quantile of the drawdowns (as suggested by Jacobsson, E., Stockholm University, in 'How to predict crashes in financial markets with the Log-Periodic Power Law', 2009).
# Second methodology: Crashes as outliers of the fitted Weibull exponential model(as suggested by Johansen, A. and Sornette, D. in 'Large Stock Market Price Drawdowns Are Outliers', 2001). This methodology requires manual identification of crashes based on the Weibull plots.
# 
# #### Crashes according to Jaccobsen

# In[127]:


crash_thresholds = []
for dd in dd_df:
    ct = dd['drawdown'].iloc[round(dd.shape[0] * .005)]
    crash_thresholds.append(ct)

crashes = []
for df, dd, ct in zip(datasets, dd_df, crash_thresholds):
    df_d = dd.reindex(df.index).fillna(0)
    df_d = df_d.sort_values(by='Date')
    df_c = df_d[df_d['drawdown'] < ct]
    df_c.columns = ['drawdown', 'crash_st', 'crash_end', 'duration', 'rank']
    crashes.append(df_c)
df_combined = []  
for i in range(len(datasets)):
    df_combined.append(pd.concat([datasets[i], dd_df[i]], axis=1).fillna(0))

for c, t in zip(crashes, plt_titles):
    c['crash_st'] = pd.to_datetime(c['crash_st'])
    c['crash_end'] = pd.to_datetime(c['crash_end'])
    
    c['crash_st'] = c['crash_st'].dt.date
    c['crash_end'] = c['crash_end'].dt.date
    c['duration'] = c['duration'].astype(int)
    print(t + ' - all crashes (99.5% drawdown quantile):')
    display(c)
    print('\n')


# On the following code, I will use Conditional Checks: The if i < len(crashes) and i < len(plt_titles): condition ensures that plotting only occurs when there's corresponding crash and title data for the current index. Skipping Missing Data: If the condition is not met, the continue statement skips the rest of the loop iteration, preventing potential errors and ensuring only valid data is plotted. GridSpec and Plots: Within the conditional block, the code sets up the grid layout for two subplots and generates the plots with price, drawdown, and volatility data, highlighting crashes with red shaded areas. Loop and Iteration: The loop continues for each element in df_combined, ensuring that only those with complete data are plotted.

# In[128]:


import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec

rcParams['figure.figsize'] = 10, 6

for i in range(len(df_combined)):
    if i < len(crashes) and i < len(plt_titles):
        gs = gridspec.GridSpec(2, 1, height_ratios=[2.5, 1])

        plt.subplot(gs[0])
        plt.plot(df_combined[i]['norm'], color='blue')
        [plt.axvspan(x1, x2, alpha=0.5, color='red') for x1, x2 in zip(crashes[i]['crash_st'], crashes[i]['crash_end'])]
        plt.plot(df_combined[i]['drawdown'], color='red', marker='v', linestyle='')
        plt.title(plt_titles[i] + ' - crashes: 99.5% drawdown quantile')
        plt.grid()
        plt.xticks([])
        plt.legend(['Price', 'Drawdown'])

        plt.subplot(gs[1])
        plt.plot(df_combined[i]['vol'])
        [plt.axvspan(x1, x2, alpha=0.5, color='red') for x1, x2 in zip(crashes[i]['crash_st'], crashes[i]['crash_end'])]
        plt.legend(['Volatility'])
        plt.grid()
        plt.tight_layout()
        plt.show()
    else:
        continue


# The plots above show the price (upper plots) and price return volatility with a lag of ten days (lower plots) along with the identified crases (vertical red lines) and the magnitude of the drawdowns (red pointers). Through the method of defining a crash as a drawdown in the 99.5th precentile, the number of crashes in each dataset is related to overall time period of each dataset. This leads to an identified crash occuring on average once 2-3 years. By identifying crashes through this methodology, the drawdown threshold for identifying a crash varies strongly with markets and we do not account for the fact that some markets have much more extreme large drawdowns than others.
# 
# #### Crashes according to Johansen and Sornette

# In[129]:


n_crashes = [3, 6, 3, 5, 8, 4, 11] 
rcParams['figure.figsize'] = 10, 4.5
for dd, t, n in zip(dd_df, plt_titles, n_crashes):
    x = dd['drawdown']
    y = dd['rank']/dd['rank'].max()
    init_vals = [0.9, 0.015] 
    best_vals, covar = curve_fit(weibull, abs(x), y, p0=init_vals)
    chi = best_vals[0]
    z = best_vals[1]
    plt.scatter(abs(x[n:]), y[n:], s=10*dd['duration'][n:], alpha=0.5, color='red')
    plt.scatter(abs(x[:n]), y[:n], s=10*dd['duration'][:n], alpha=0.5, color='black', marker='x')
    y_fit = [weibull(abs(xi), chi, z) for xi in x]
    plt.plot(abs(x), y_fit, color='black', ls='dashed')
    plt.yscale('log')
    plt.ylim(bottom=10**-4)
    plt.legend(['Drawdowns', 'Weibull fit', 'Outliers'])
    plt.title(t + ' - fit Weibull distribution to drawdowns')
    plt.xlabel('Drawdown loss')
    plt.ylabel('Drawdown rank (log, normalized)')
    plt.grid()
    plt.show()


# The Weibull fit plots above are the same ones as shown under 2. but this time with the "x"s identifying outliers that cannot be explained by the Weibull distribution. As Johansen and Sornette do not give a specific threshold deviation from the distribution that identifies a crash, the identification of crashes above has been conducted based on visual interpretation.

# In[130]:


crashes = []
for df, dd, r in zip(datasets, dd_df, n_crashes):
    df_c = dd[dd['rank'] <= r]
    df_c.columns = ['drawdown', 'crash_st', 'crash_end', 'duration', 'rank']
    crashes.append(df_c)

for c, t in zip(crashes, plt_titles):
    c['crash_st'] = c['crash_st'].dt.date
    c['crash_end'] = c['crash_end'].dt.date
    c['duration'] = c['duration'].astype(int)
    c['rank'] = c['rank'].astype(int)
    print(t + ' - all crashes (Weibull outliers):')
    display(c)
    print('\n')


# In[131]:


import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec

rcParams['figure.figsize'] = 10, 6

for i in range(len(df_combined)):
    if i < len(crashes) and i < len(plt_titles):
        gs = gridspec.GridSpec(2, 1, height_ratios=[2.5, 1])

        plt.subplot(gs[0])
        plt.plot(df_combined[i]['norm'], color='blue')
        [plt.axvspan(x1, x2, alpha=0.5, color='red') for x1, x2 in zip(crashes[i]['crash_st'], crashes[i]['crash_end'])]
        plt.plot(df_combined[i]['drawdown'], color='red', marker='v', linestyle='')
        plt.title(plt_titles[i] + ' - crashes: Weibull outliers')
        plt.grid()
        plt.xticks([])
        plt.legend(['Price', 'Drawdown'])

        plt.subplot(gs[1])
        plt.plot(df_combined[i]['vol'])
        [plt.axvspan(x1, x2, alpha=0.5, color='red') for x1, x2 in zip(crashes[i]['crash_st'], crashes[i]['crash_end'])]
        plt.legend(['Volatility'])
        plt.grid()
        plt.tight_layout()
        plt.show()
    else:
        continue


# On the next plot: The only change made was to the title of the plot, which now correctly reflects the use of Weibull outliers instead of 99.5% drawdown quantile. The rest of the code remains the same, ensuring that crashes are highlighted with red shaded areas in both the price and volatility subplots.

# In[132]:


rcParams['figure.figsize'] = (10, 6)
gs = gridspec.GridSpec(2, 1, height_ratios=[2.5, 1])

min_length = min(len(df_combined), len(crashes))

for i in range(min_length):
    plt.subplot(gs[0])
    plt.plot(df_combined[i]['norm'], color='blue')
    [plt.axvspan(x1, x2, alpha=0.5, color='red') for x1, x2 in zip(crashes[i]['crash_st'], \
         crashes[i]['crash_end'])]
    plt.plot(df_combined[i]['drawdown'], color='red', marker='v', linestyle='')
    plt.title(plt_titles[i] + ' - crashes: Weibull outliers')
    plt.grid()
    plt.xticks([])
    plt.legend(['Price', 'Drawdown'])
    plt.subplot(gs[1])
    plt.plot(df_combined[i]['vol'])
    [plt.axvspan(x1, x2, alpha=0.5, color='red') for x1, x2 in zip(crashes[i]['crash_st'], \
         crashes[i]['crash_end'])]
    plt.legend(['Volatility'])
    plt.grid()
    plt.tight_layout()
    plt.show()


# Identifying crashes based on drawdown outliers results in a number of crahes that doesn't necessarily correspond to the total number of drawdowns in a dataset. There are for example only three identified crashes over 68 years in the S&P whereas there are 11 crashes in just 16 years of BVSP.
# 
# Conclusion
# Since there is no consensus on the exact definition of a financial crash, both, the method introduced by Jacobsson (99.5% quantile of drawdowns) and the method introduced by Johansen and Sornette (outliers identified with the Weibull exponential model) can be used as an approach to identify crashes. For this project, I will be using the quantile method as it is unambiguous (no manual interpretation of outliers required) and leads to a number of crashes which proportional to the length of each dataset and therefore reduces the risk of overfitting crash patterns in certain datasets.

# In[ ]:


# specify drawdown thresholds for crashes (determined in exploration.ipynb):
# crashes according to Jacobsson:
crash_thresholds = [-0.0936, -0.1101, -0.1269, -0.1470, -0.1703, -0.1106, -0.2344]
# crashes according to Sornette:
# crash_thresholds = [-0.1053, -0.1495, -0.1706, -0.2334, -0.1563, -0.1492, -0.2264]
months = [1, 3, 6]   # <-- predict if crash n months ahead
data = DataLoader(datasets_original, dataset_names)
datasets_revised, crashes = data.get_data_revised(crash_thresholds)
dfs_x, dfs_y = data.get_dfs_xy(months=months)


# In[ ]:


# -------------------- Find best parameters with grid search -------------------- #
model_name = 'Decision Trees'
test_data = 'S&P 500'
month_prediction = 3
beta = 2

index_test = [i for i, name in enumerate(dataset_names) if name == test_data][0]
index_month = [i for i, m in enumerate(months) if m == month_prediction][0]
training_set_names = list(dataset_names)
training_set_names.pop(index_test)
dfs_x_training = list(dfs_x)
dfs_x_training.pop(index_test)
dfs_y_training = list(dfs_y)
dfs_y_training.pop(index_test)
x_train, y_train, _, _ = data.get_train_test(dfs_x_training, dfs_y_training, \
            training_set_names, test_data=None)
y_train = y_train[:, index_month].astype(int)

# Find parameters with grid search:
fbeta_scorer = make_scorer(fbeta_score, beta=beta)
param_grid = [{'max_depth': [16, 20, 24, 28, 32, 36, None], 'criterion': ['gini', 'entropy']}]
clf_tree = tree.DecisionTreeClassifier()
clf = GridSearchCV(clf_tree, param_grid, scoring=fbeta_scorer)
model = clf.fit(x_train, y_train)
labels = model.cv_results_['params']
tr_score = model.cv_results_['mean_train_score']
t_score = model.cv_results_['mean_test_score']

# Plot grid search results
plt.plot(t_score)
plt.title('Find best parameters with F beta score (beta=2)')
plt.xticks(np.arange(len(labels)), labels, rotation=90)
plt.xlabel('F-Beta score (beta=2)')
plt.ylim(0, 0.2)
plt.grid()
plt.show()


# In[ ]:


# -------------------- Train Decision Trees -------------------- #
max_depth = 24
criterion='entropy'

index_test = [i for i, name in enumerate(dataset_names) if name == test_data][0]
index_month = [i for i, m in enumerate(months) if m == month_prediction][0]
training_set_names = list(dataset_names)
training_set_names.pop(index_test)
dfs_x_training = list(dfs_x)
dfs_x_training.pop(index_test)
dfs_y_training = list(dfs_y)
dfs_y_training.pop(index_test)
y_train_all, y_val_all = [], []
y_pred_train_all, y_pred_val_all = [], []
for val_data in training_set_names:
    x_train, y_train, x_val, y_val = data.get_train_test(dfs_x_training, dfs_y_training, \
            training_set_names, test_data=val_data)
    y_train, y_val = y_train[:, index_month].astype(int), y_val[:, index_month].astype(int)
    y_train_all.append(y_train)
    y_val_all.append(y_val)
    print('Train ' + str(model_name) + ' - validation data: ' + str(val_data))
    clf = tree.DecisionTreeClassifier(criterion=criterion, max_depth=max_depth)
    model = clf.fit(x_train, y_train)
    y_pred_train = model.predict(x_train)
    y_pred_train_all.append(y_pred_train)
    y_pred_val = model.predict(x_val)
    y_pred_val_all.append(y_pred_val)


# In[ ]:


# -------------------- Evaluate results -------------------- #
eval_ = EvaluateResults(y_train_all, y_val_all, y_pred_train_all, y_pred_val_all, model_name, \
            test_data)
beta = 2
threshold = None
print(model_name)
print('\n')
print('Predict crash in:            ' + str(month_prediction) + ' months')
print('Threshold for positives:     ' + str(threshold))
print('Number of features:          ' + str(dfs_x[0].shape[1]))
print('Number of rows for training: ' + str(len(y_pred_train_all[0]) + len(y_pred_val_all[0])))
print('\n')
eval_.training_results(threshold, training_set_names, beta=beta)


# In[ ]:


# -------------------- Test model -------------------- #
x_train, y_train, x_test, y_test = data.get_train_test(dfs_x, dfs_y, dataset_names, test_data=test_data)
y_train, y_test = y_train[:, index_month].astype(int), y_test[:, index_month].astype(int)
clf = tree.DecisionTreeClassifier(criterion=criterion, max_depth=max_depth)
model = clf.fit(x_train, y_train)
y_pred_test_bin = model.predict(x_test).astype(int)
threshold = None
_ = eval_.test_results(y_test, y_pred_test_bin, threshold, beta=beta)


# In[ ]:


# -------------------- Plot test results -------------------- #
df = datasets_revised[index_test].reindex(dfs_x[index_test].index)
df['y'] = y_test
df['y_pred'] = y_pred_test_bin
c = crashes[index_test]
t_start = ['1956-01-01', '1971-01-01', '1976-01-01', '1983-01-01', '1995-01-01', '2004-01-01', '2010-01-01']
t_end = ['1963-01-01', '1981-01-01', '1983-01-01', '1988-01-01', '2003-01-01', '2010-01-01', '2016-01-01']
rcParams['figure.figsize'] = 10, 6
eval_.plot_test_results(df, c, t_start, t_end)


# ### Predicting Crashes in Financial Markets - Linear Regression
# Datasets: S&P500 (USA), Nikkei225 (Japan), SSE (Shanghai/China), HSI (Hong Kong), BSESN (India), SMI (Switzerland), BVSP (Brazil)
# 
# Model: Linear Regression
# 
# Number of features: 504 (252 past days of price chages and volatility for each trading date)
# 
# Response variable: Crash within 1 / 3 / 6 months (0: no, 1:yes)
# 
# Crash definition: Drawdown in 99.5% quantile

# In[ ]:


# -------------------- Train Linear Regression -------------------- #
model_name = 'Linear Regression'
test_data = 'S&P 500'
month_prediction = 3
index_test = [i for i, name in enumerate(dataset_names) if name == test_data][0]
index_month = [i for i, m in enumerate(months) if m == month_prediction][0]
training_set_names = list(dataset_names)
training_set_names.pop(index_test)
dfs_x_training = list(dfs_x)
dfs_x_training.pop(index_test)
dfs_y_training = list(dfs_y)
dfs_y_training.pop(index_test)
y_train_all, y_val_all = [], []
y_pred_train_all, y_pred_val_all = [], []
for val_data in training_set_names:
    x_train, y_train, x_val, y_val = data.get_train_test(dfs_x_training, dfs_y_training, \
            training_set_names, test_data=val_data)
    y_train, y_val = y_train[:, index_month].astype(int), y_val[:, index_month].astype(int)
    y_train_all.append(y_train)
    y_val_all.append(y_val)
    print('Train ' + str(model_name) + ' - validation data: ' + str(val_data))
    lm = linear_model.LinearRegression()
    model = lm.fit(x_train, y_train)
    y_pred_train = model.predict(x_train)
    y_pred_train_all.append(y_pred_train)
    y_pred_val = model.predict(x_val)
    y_pred_val_all.append(y_pred_val)


# In[ ]:


# -------------------- Find best threshold -------------------- #
beta = 2
rcParams['figure.figsize'] = 14, 4
eval_ = EvaluateResults(y_train_all, y_val_all, y_pred_train_all, y_pred_val_all, model_name,\
            test_data)
eval_.find_threshold(beta=beta, threshold_min=0.01, threshold_max=0.15, resolution=40)


# In[ ]:


# -------------------- Evaluate results -------------------- #
threshold = 0.075
beta = 2
print(model_name)
print('\n')
print('Predict crash in:            ' + str(month_prediction) + ' months')
print('Threshold for positives:     ' + str(threshold))
print('Number of features:          ' + str(dfs_x[0].shape[1]))
print('Number of rows for training: ' + str(len(y_pred_train_all[0]) + len(y_pred_val_all[0])))
print('\n')
eval_.training_results(threshold, training_set_names, beta=beta)


# In[ ]:


# -------------------- Test model -------------------- #
x_train, y_train, x_test, y_test = data.get_train_test(dfs_x, dfs_y, dataset_names, test_data)
y_train, y_test = y_train[:, index_month].astype(int), y_test[:, index_month].astype(int)
lm = linear_model.LinearRegression()
model = lm.fit(x_train, y_train)
y_pred_test = model.predict(x_test)
y_pred_test_bin = eval_.test_results(y_test, y_pred_test, threshold, beta=beta)


# In[ ]:


# -------------------- Plot test results -------------------- #
df = datasets_revised[index_test].reindex(dfs_x[index_test].index)
df['y'] = y_test
df['y_pred'] = y_pred_test_bin
c = crashes[index_test]
t_start = ['1956-01-01', '1971-01-01', '1976-01-01', '1983-01-01', '1995-01-01', '2004-01-01',\
            '2010-01-01']
t_end = ['1963-01-01', '1981-01-01', '1983-01-01', '1988-01-01', '2003-01-01', '2010-01-01', \
            '2016-01-01']
rcParams['figure.figsize'] = 10, 6
eval_.plot_test_results(df, c, t_start, t_end)


# In[ ]:


# -------------------- Current prediction S&P 500 -------------------- #
# train on all available data:
x_train, y_train, _, _ = data.get_train_test(dfs_x, dfs_y, dataset_names, test_data=None)
thresholds = [0.07, 0.075, 0.085] # <-- determined by eval model for each prediction
dataset_original = ['^GSPC.txt']
dataset_name = ['S&P 500']
crash_threshold = [-0.0936]
data_new = DataLoader(dataset_original, dataset_name)
dataset_revised, crashes = data_new.get_data_revised(crash_threshold)
dfs_x_new, dfs_y_new = data_new.get_dfs_xy_predict(months=months)
x_new, _, _, _ = data_new.get_train_test(dfs_x_new, dfs_y_new, dataset_name, test_data=None)

for index_month in range(len(months)):
    y_train_ = y_train[:, index_month].astype(int)
    lm = linear_model.LinearRegression()
    model = lm.fit(x_train, y_train_)
    y_pred_new = model.predict(x_new)
    y_pred_new_bin = y_pred_new > thresholds[index_month]
    y_pred_new_bin = y_pred_new_bin.astype(int)
    current_pred = np.dot(np.linspace(0,1,42)/sum(np.linspace(0,1,42)), y_pred_new_bin[-42:])
    print(str(model_name) + ' prediction of a crash within ' + str(months[index_month]) \
          + ' months: ' + str(np.round(current_pred, 2)))


# ### Predicting Crashes in Financial Markets - Linear Regression
# 
# Datasets: S&P500 (USA), Nikkei225 (Japan), SSE (Shanghai/China), HSI (Hong Kong), BSESN (India), SMI (Switzerland), BVSP (Brazil)
# 
# Model: Linear Regression
# 
# Number of features: 504 (252 past days of price chages and volatility for each trading date)
# 
# Response variable: Crash within 1 / 3 / 6 months (0: no, 1:yes)
# 
# Crash definition: Drawdown in 99.5% quantile

# In[ ]:


# -------------------- Train Linear Regression -------------------- #
model_name = 'Linear Regression'
test_data = 'S&P 500'
month_prediction = 3
index_test = [i for i, name in enumerate(dataset_names) if name == test_data][0]
index_month = [i for i, m in enumerate(months) if m == month_prediction][0]
training_set_names = list(dataset_names)
training_set_names.pop(index_test)
dfs_x_training = list(dfs_x)
dfs_x_training.pop(index_test)
dfs_y_training = list(dfs_y)
dfs_y_training.pop(index_test)
y_train_all, y_val_all = [], []
y_pred_train_all, y_pred_val_all = [], []
for val_data in training_set_names:
    x_train, y_train, x_val, y_val = data.get_train_test(dfs_x_training, dfs_y_training, \
            training_set_names, test_data=val_data)
    y_train, y_val = y_train[:, index_month].astype(int), y_val[:, index_month].astype(int)
    y_train_all.append(y_train)
    y_val_all.append(y_val)
    print('Train ' + str(model_name) + ' - validation data: ' + str(val_data))
    lm = linear_model.LinearRegression()
    model = lm.fit(x_train, y_train)
    y_pred_train = model.predict(x_train)
    y_pred_train_all.append(y_pred_train)
    y_pred_val = model.predict(x_val)
    y_pred_val_all.append(y_pred_val)


# In[ ]:


# -------------------- Find best threshold -------------------- #
beta = 2
rcParams['figure.figsize'] = 14, 4
eval_ = EvaluateResults(y_train_all, y_val_all, y_pred_train_all, y_pred_val_all, model_name,\
            test_data)
eval_.find_threshold(beta=beta, threshold_min=0.01, threshold_max=0.15, resolution=40)


# In[ ]:


# -------------------- Evaluate results -------------------- #
threshold = 0.075
beta = 2
print(model_name)
print('\n')
print('Predict crash in:            ' + str(month_prediction) + ' months')
print('Threshold for positives:     ' + str(threshold))
print('Number of features:          ' + str(dfs_x[0].shape[1]))
print('Number of rows for training: ' + str(len(y_pred_train_all[0]) + len(y_pred_val_all[0])))
print('\n')
eval_.training_results(threshold, training_set_names, beta=beta)


# In[ ]:


# -------------------- Test model -------------------- #
x_train, y_train, x_test, y_test = data.get_train_test(dfs_x, dfs_y, dataset_names, test_data)
y_train, y_test = y_train[:, index_month].astype(int), y_test[:, index_month].astype(int)
lm = linear_model.LinearRegression()
model = lm.fit(x_train, y_train)
y_pred_test = model.predict(x_test)
y_pred_test_bin = eval_.test_results(y_test, y_pred_test, threshold, beta=beta)


# In[ ]:


# -------------------- Plot test results -------------------- #
df = datasets_revised[index_test].reindex(dfs_x[index_test].index)
df['y'] = y_test
df['y_pred'] = y_pred_test_bin
c = crashes[index_test]
t_start = ['1956-01-01', '1971-01-01', '1976-01-01', '1983-01-01', '1995-01-01', '2004-01-01',\
            '2010-01-01']
t_end = ['1963-01-01', '1981-01-01', '1983-01-01', '1988-01-01', '2003-01-01', '2010-01-01', \
            '2016-01-01']
rcParams['figure.figsize'] = 10, 6
eval_.plot_test_results(df, c, t_start, t_end)


# In[ ]:


# -------------------- Current prediction S&P 500 -------------------- #
# train on all available data:
x_train, y_train, _, _ = data.get_train_test(dfs_x, dfs_y, dataset_names, test_data=None)
thresholds = [0.07, 0.075, 0.085] 
dataset_original = ['^GSPC.txt']
dataset_name = ['S&P 500']
crash_threshold = [-0.0936]
data_new = DataLoader(dataset_original, dataset_name)
dataset_revised, crashes = data_new.get_data_revised(crash_threshold)
dfs_x_new, dfs_y_new = data_new.get_dfs_xy_predict(months=months)
x_new, _, _, _ = data_new.get_train_test(dfs_x_new, dfs_y_new, dataset_name, test_data=None)

for index_month in range(len(months)):
    y_train_ = y_train[:, index_month].astype(int)
    lm = linear_model.LinearRegression()
    model = lm.fit(x_train, y_train_)
    y_pred_new = model.predict(x_new)
    y_pred_new_bin = y_pred_new > thresholds[index_month]
    y_pred_new_bin = y_pred_new_bin.astype(int)
    current_pred = np.dot(np.linspace(0,1,42)/sum(np.linspace(0,1,42)), y_pred_new_bin[-42:])
    print(str(model_name) + ' prediction of a crash within ' + str(months[index_month]) \
          + ' months: ' + str(np.round(current_pred, 2)))


# ### Predicting Crashes in Financial Markets - Logistic Regression
# 
# Datasets: S&P500 (USA), Nikkei225 (Japan), SSE (Shanghai/China), HSI (Hong Kong), BSESN (India), SMI (Switzerland), BVSP (Brazil)
# 
# Model: Logistic Regression
# 
# Number of features: 16 (mean price change and volatility for different windows over past 252 days)
# 
# Response variable: Crash within 1 / 3 / 6 months (0: no, 1: yes)
# 
# Crash definition: Drawdown in 99.5% quantile

# In[ ]:


# -------------------- Find best parameters with grid search -------------------- #
model_name = 'Logistic Regression'
test_data = 'S&P 500'
month_prediction = 3
beta = 2

index_test = [i for i, name in enumerate(dataset_names) if name == test_data][0]
index_month = [i for i, m in enumerate(months) if m == month_prediction][0]
training_set_names = list(dataset_names)
training_set_names.pop(index_test)
dfs_x_training = list(dfs_x)
dfs_x_training.pop(index_test)
dfs_y_training = list(dfs_y)
dfs_y_training.pop(index_test)
x_train, y_train, _, _ = data.get_train_test(dfs_x_training, dfs_y_training, \
            training_set_names, test_data=None)
y_train = y_train[:, index_month].astype(int)

# Find parameters with grid search:
fbeta_scorer = make_scorer(fbeta_score, beta=beta)
# param_grid = [{'C': [0.1, 1, 10, 100, 1000], 'class_weight': [{0:.05, 1:.95}, {0:.04, 1:.96}, \
#               {0:.03, 1:.97}, {0:.025, 1:.975}, {0:.02, 1:.98}]}]   # <-- 1 month
param_grid = [{'C': [0.1, 1, 10, 100, 1000], 'class_weight': [{0:.07, 1:.93}, {0:.06, 1:.94}, \
                {0:.05, 1:.95}, {0:.04, 1:.96}]}]   # <-- 3 months
# param_grid = [{'C': [0.1, 1, 10, 100, 1000], 'class_weight': [{0:.11, 1:.89}, {0:.1, 1:.9},\
#                 {0:.09, 1:.91}, {0:.08, 1:.92}]}]   # <-- 6 months

clf = GridSearchCV(linear_model.LogisticRegression(penalty='l2'), param_grid, scoring=fbeta_scorer) 
model = clf.fit(x_train, y_train)
labels = model.cv_results_['params']
tr_score = model.cv_results_['mean_train_score']
t_score = model.cv_results_['mean_test_score']
rcParams['figure.figsize'] = 8, 4
plt.bar(x=np.arange(len(tr_score)) - 0.2,width=0.4, height=tr_score, color='lightblue', label='train score')
plt.bar(x=np.arange(len(t_score)) + 0.2,width=0.4, height=t_score, color='blue', label='test score')
plt.title('Find best parameters with F beta score (beta=2)')
plt.xticks(np.arange(len(labels)), labels, rotation=90)
plt.ylabel('F-Beta score (beta=2)')
plt.legend()
plt.grid()
plt.show()


# In[ ]:


# -------------------- Train Logistic Regression -------------------- #
class_weight = {0:.06, 1:.94}
C = 1
index_test = [i for i, name in enumerate(dataset_names) if name == test_data][0]
index_month = [i for i, m in enumerate(months) if m == month_prediction][0]
training_set_names = list(dataset_names)
training_set_names.pop(index_test)
dfs_x_training = list(dfs_x)
dfs_x_training.pop(index_test)
dfs_y_training = list(dfs_y)
dfs_y_training.pop(index_test)
y_train_all, y_val_all = [], []
y_pred_train_all, y_pred_val_all = [], []
for val_data in training_set_names:
    x_train, y_train, x_val, y_val = data.get_train_test(dfs_x_training, dfs_y_training, \
            training_set_names, test_data=val_data)
    y_train, y_val = y_train[:, index_month].astype(int), y_val[:, index_month].astype(int)
    y_train_all.append(y_train)
    y_val_all.append(y_val)
    print('Train ' + str(model_name) + ' - validation data: ' + str(val_data))
    clf = linear_model.LogisticRegression(C=C, class_weight=class_weight)
    model = clf.fit(x_train, y_train)
    y_pred_train = model.predict(x_train)
    y_pred_train_all.append(y_pred_train)
    y_pred_val = model.predict(x_val)
    y_pred_val_all.append(y_pred_val)


# In[ ]:


# -------------------- Evaluate results -------------------- #
eval_ = EvaluateResults(y_train_all, y_val_all, y_pred_train_all, y_pred_val_all, model_name, test_data)
beta = 2
threshold = None
print(model_name)
print('\n')
print('Predict crash in:               ' + str(month_prediction) + ' months')
print('Number of features:             ' + str(dfs_x[0].shape[1]))
print('Number of rows in training set: ' + str(len(y_pred_train_all[0]) + len(y_pred_val_all[0])))
print('\n')
eval_.training_results(threshold, training_set_names, beta=beta)


# In[ ]:


# -------------------- Test model -------------------- #
x_train, y_train, x_test, y_test = data.get_train_test(dfs_x, dfs_y, dataset_names, test_data=test_data)
y_train, y_test = y_train[:, index_month].astype(int), y_test[:, index_month].astype(int)
lm = linear_model.LogisticRegression(C=C, class_weight=class_weight)
model = lm.fit(x_train, y_train)
y_pred_test_bin = model.predict(x_test).astype(int)
threshold = None
_ = eval_.test_results(y_test, y_pred_test_bin, threshold, beta=beta)


# In[ ]:


# -------------------- Plot test results -------------------- #
df = datasets_revised[index_test].reindex(dfs_x[index_test].index)
df['y'] = y_test
df['y_pred'] = y_pred_test_bin
c = crashes[index_test]
t_start = ['1956-01-01', '1971-01-01', '1976-01-01', '1983-01-01', '1995-01-01', '2004-01-01', '2010-01-01']
t_end = ['1963-01-01', '1981-01-01', '1983-01-01', '1988-01-01', '2003-01-01', '2010-01-01', '2016-01-01']
rcParams['figure.figsize'] = 10, 6
eval_.plot_test_results(df, c, t_start, t_end)


# In[ ]:


# -------------------- Current prediction S&P 500 -------------------- #
x_train, y_train, _, _ = data.get_train_test(dfs_x, dfs_y, dataset_names, test_data=None)
C = [1, 1, 1]
class_weights = [{0:.06, 1:.94}, {0:.06, 1:.94}, {0:.08, 1:.92}]
dataset_original = ['^GSPC.txt']
dataset_name = ['S&P 500']
crash_threshold = [-0.0936]
data_new = DataLoader(dataset_original, dataset_name)
dataset_revised, crashes = data_new.get_data_revised(crash_threshold)
dfs_x_new, dfs_y_new = data_new.get_dfs_xy_predict(months=months)
x_new, _, _, _ = data_new.get_train_test(dfs_x_new, dfs_y_new, dataset_name, test_data=None)

os.chdir('/home/roman/Documents/Projects/Bubbles/models')
for index_month in range(len(months)):
    y_train_ = y_train[:, index_month].astype(int)
    lm = linear_model.LogisticRegression(C=C[index_month], class_weight=class_weights[index_month])
    model = lm.fit(x_train, y_train_)
    filename = 'logreg_model_{}months.sav'.format(months[index_month])
    pickle.dump(model, open(filename, 'wb'))
    y_pred_new_bin = model.predict(x_new).astype(int)
    current_pred = np.dot(np.linspace(0,1,21) / sum(np.linspace(0,1,21)), y_pred_new_bin[-21:])
    print(str(model_name) + ' prediction of a crash within ' + str(months[index_month]) \
          + ' months: ' + str(np.round(current_pred, 2)))


# ### Predicting Crashes in Financial Markets - RNN LSTM
# 
# Datasets: S&P500 (USA), Nikkei225 (Japan), SSE (Shanghai/China), HSI (Hong Kong), BSESN (India), SMI (Switzerland), BVSP (Brazil)
# 
# Model: RNN LSTM (stateful)
# 
# Response variable: Crash within 1, 3 and 6 months (0: no, 1: yes)
# 
# Crash definition: Drawdown in 99.5% quantile
# 
# Sequence: price changes over past 5 trading days

# In[ ]:


# -------------------- RNN LSTM model -------------------- #
model_name = 'RNN LSTM'
neurons = 50
dropout = 0
optimizer = 'adam'
loss = 'binary_crossentropy'
activation = 'sigmoid'
stateful = True
inp_dim = 1   # <-- 1 if price change only, 2 if volatility as well
inp_tsteps = sequence + 4 * additional_feat
def rnn_lstm(inp_tsteps, inp_dim, neurons, dropout):
    model = Sequential()
    model.add(LSTM(neurons, batch_input_shape=(batch_size, inp_tsteps, inp_dim), \
            stateful=stateful, return_sequences=True))
    model.add(LSTM(neurons, stateful=stateful, return_sequences=False))
    model.add(Dense(3, activation=activation))
    return model
model = rnn_lstm(neurons=neurons, inp_tsteps=inp_tsteps, inp_dim=inp_dim, dropout=dropout)
model.compile(loss=loss, optimizer=optimizer)
model.summary()


# In[ ]:


# -------------------- Train and test RNN LSTM model -------------------- #
epochs = 40
test_data = 'S&P 500'
index_test = [i for i, name in enumerate(dataset_names) if name == test_data][0]
training_set_names = list(dataset_names)
training_set_names.pop(index_test)
dfs_x1_training = list(dfs_x1)
dfs_x1_training.pop(index_test)
dfs_x2_training = list(dfs_x1)
dfs_x2_training.pop(index_test)
dfs_y_training = list(dfs_y)
dfs_y_training.pop(index_test)

for val_data in training_set_names:
    model = rnn_lstm(neurons=neurons, inp_tsteps=inp_tsteps, inp_dim=1, dropout=dropout)
    model.compile(loss=loss, optimizer=optimizer, metrics=['accuracy']) 
    print('Train ' + str(model_name) + ' - val data: ' + str(val_data))
    for e in range(epochs):
        np_train_x_l, _, np_train_y_l = data.get_train_stateful(dfs_x1_training, dfs_x2_training,\
            dfs_y_training, training_set_names, test_data=val_data)
        i = 0
        for np_tr_x, np_tr_y in zip(np_train_x_l, np_train_y_l):
            i += 1
            x_tr = np.expand_dims(np_tr_x, axis=2)
            y_tr = np_tr_y.astype(int)
            model.fit(x_tr, y_tr, epochs=1, batch_size=batch_size, verbose=0, shuffle=False)
            model.reset_states()
            if (e + 1) % 10 == 0 and i == len(np_train_x_l):
                model.save_weights('stateful_all_{0}_{1}.hdf5'.format(val_data, e + 1))


# In[ ]:


# -------------------- Load weights and predict results -------------------- #
epoch = 40 # <-- change to load model weights from previous epochs
y_train_all, y_val_all = [], []
y_pred_train_all, y_pred_val_all = [], []
for val_data in training_set_names:
    np_x_train, _, np_y_train, np_x_val, _, np_y_val = \
        data.get_train_test(dfs_x1_training, dfs_x2_training, dfs_y_training, \
                training_set_names, test_data=val_data)
    y_train_all.append(np_y_train)
    y_val_all.append(np_y_val)
    model.load_weights('stateful_all_{0}_{1}.hdf5'.format(val_data, epoch))
    y_pred_train = model.predict(np_x_train, batch_size=batch_size, verbose=True) 
    y_pred_train_all.append(y_pred_train)
    y_pred_val = model.predict(np_x_val, batch_size=batch_size, verbose=True)
    y_pred_val_all.append(y_pred_val)


# In[ ]:


# -------------------- Find best threshold -------------------- #
month_prediction = 3
index_month = [i for i, m in enumerate(months) if m == month_prediction][0]
y_train_all_ = [y[:, index_month] for y in y_train_all]
y_val_all_ = [y[:, index_month] for y in y_val_all]
y_pred_train_all_ = [y[:, index_month] for y in y_pred_train_all]
y_pred_val_all_ = [y[:, index_month] for y in y_pred_val_all]
beta = 2
rcParams['figure.figsize'] = 14, 4
eval_ = EvaluateResults(y_train_all_, y_val_all_, y_pred_train_all_, y_pred_val_all_, model_name, test_data)
eval_.find_threshold(beta=beta, threshold_min=0.005, threshold_max=0.15, resolution=40)


# In[ ]:


# -------------------- Evaluate results -------------------- #
threshold = 0.07
beta = 2
print(model_name)
print('\n')
print('Predict crash in:               ' + str(month_prediction) + ' months')
print('Threshold for positives:        ' + str(threshold))
print('Number of features:             ' + str(dfs_x1[0].shape[1] + dfs_x2[0].shape[1]))
print('Number of rows in training set: ' + str(len(y_pred_train_all[0]) + len(y_pred_val_all[0])))
print('Number of epochs:               ' + str(epoch))
print('Sequence length:                ' + str(sequence))
print('Number of neurons/layer:        ' + str(neurons))
print('Batch size:                     ' + str(batch_size))
print('Optimizer:                      ' + str(optimizer))
print('Loss function:                  ' + str(loss))
print('\n')
eval_.training_results(threshold, training_set_names, beta=beta)


# In[ ]:


# -------------------- Train model on all training data for testing -------------------- #
epochs = 40
test_data = 'S&P 500'
index_test = [i for i, name in enumerate(dataset_names) if name == test_data][0]
model = rnn_lstm(neurons=neurons, inp_tsteps=inp_tsteps, inp_dim=1, dropout=dropout)
model.compile(loss=loss, optimizer=optimizer, metrics=['accuracy']) 
print('Train model for testing ' + str(model_name))
for e in range(epochs):
    np_train_x_l, _, np_train_y_l = data.get_train_stateful(dfs_x1, dfs_x2,\
        dfs_y, dataset_names, test_data=test_data)
    i = 0
    for np_tr_x, np_tr_y in zip(np_train_x_l, np_train_y_l):
        i += 1
        x_tr = np.expand_dims(np_tr_x, axis=2)
        y_tr = np_tr_y.astype(int)
        model.fit(x_tr, y_tr, epochs=1, batch_size=batch_size, verbose=0, shuffle=False)
        model.reset_states()
        if (e + 1) % 5 == 0 and i == len(np_train_x_l):
            model.save_weights('stateful_final_{0}_{1}.hdf5'.format(test_data, e + 1))


# In[ ]:


# -------------------- Test model -------------------- #
test_data = 'S&P 500'
epoch = 40
threshold = 0.07
month_prediction = 3   # <-- predict crash in 1, 3 or 6 months
index_month = [i for i, m in enumerate(months) if m == month_prediction][0]
_, _, _, np_x1_test, _, np_y_test = \
    data.get_train_test(dfs_x1, dfs_x2, dfs_y, dataset_names, test_data=test_data)
#np_x_test = np.concatenate([np_x1_test, np_x2_test], axis=2)
model.load_weights('stateful_final_{0}_{1}.hdf5'.format(test_data, epoch))
y_pred_test = model.predict(np_x1_test, batch_size=batch_size)[:, index_month]
y_test = np_y_test[:, index_month]
y_pred_test_bin = eval_.test_results(y_test, y_pred_test, threshold, beta=beta)


# In[ ]:


# -------------------- Plot test results -------------------- #
df = datasets_revised[index_test].reindex(dfs_x1[index_test].index)
df['y'] = y_test
df['y_pred'] = y_pred_test_bin
c = crashes[index_test]
t_start = ['1956-01-01', '1971-01-01', '1976-01-01', '1983-01-01', '1995-01-01', '2004-01-01', '2010-01-01']
t_end = ['1963-01-01', '1981-01-01', '1983-01-01', '1988-01-01', '2003-01-01', '2010-01-01', '2016-01-01']
rcParams['figure.figsize'] = 10, 6
eval_.plot_test_results(df, c, t_start, t_end)


# ### Predicting Crashes in Financial Markets - Support Vector Machines
# Datasets: S&P500 (USA), Nikkei225 (Japan), SSE (Shanghai/China), HSI (Hong Kong), BSESN (India), SMI (Switzerland), BVSP (Brazil)
# 
# Model: Support Vecor Machines (SVM)
# 
# Number of features: 16 (mean price change and volatility for different windows over past 252 days)
# 
# Response variable: Crash within 1, 3 or 6 months (0: no, 1:yes)
# 
# Crash definition: Drawdown in 99.5% quantile

# In[ ]:


# -------------------- Train SVM linear -------------------- #
model_name = 'SVM: linear Classification'
test_data = 'S&P 500'
month_prediction = 3
kernel = 'linear'
C = 1
class_weight = {0:.06, 1:.94}

index_test = [i for i, name in enumerate(dataset_names) if name == test_data][0]
index_month = [i for i, m in enumerate(months) if m == month_prediction][0]
training_set_names = list(dataset_names)
training_set_names.pop(index_test)
dfs_x_training = list(dfs_x)
dfs_x_training.pop(index_test)
dfs_y_training = list(dfs_y)
dfs_y_training.pop(index_test)
y_train_all, y_val_all = [], []
y_pred_train_all, y_pred_val_all = [], []
for val_data in training_set_names:
    x_train, y_train, x_val, y_val = data.get_train_test(dfs_x_training, dfs_y_training, \
            training_set_names, test_data=val_data)
    y_train, y_val = y_train[:, index_month].astype(int), y_val[:, index_month].astype(int)
    y_train_all.append(y_train)
    y_val_all.append(y_val)
    print('Train ' + str(model_name) + ' - validation data: ' + str(val_data))
    clf = svm.SVC(C=C, kernel=kernel, class_weight=class_weight)
    model = clf.fit(x_train, y_train)
    y_pred_train = model.predict(x_train)
    y_pred_train_all.append(y_pred_train)
    y_pred_val = model.predict(x_val)
    y_pred_val_all.append(y_pred_val)


# In[ ]:


# -------------------- Evaluate results -------------------- #
eval_ = EvaluateResults(y_train_all, y_val_all, y_pred_train_all, y_pred_val_all, model_name,\
            test_data)
beta = 2
threshold = None
print(model_name)
print('\n')
print('Predict crash in:               ' + str(month_prediction) + ' months')
print('Threshold for positives:        ' + str(threshold))
print('Number of features:             ' + str(dfs_x[0].shape[1]))
print('Number of rows in training set: ' + str(len(y_pred_train_all[0]) + len(y_pred_val_all[0])))
print('\n')
eval_.training_results(threshold, training_set_names, beta=beta)


# In[ ]:


# -------------------- Test model -------------------- #
x_train, y_train, x_test, y_test = data.get_train_test(dfs_x, dfs_y, dataset_names,\
            test_data=test_data)
y_train, y_test = y_train[:, index_month].astype(int), y_test[:, index_month].astype(int)
clf = svm.SVC(C=C, kernel=kernel, class_weight=class_weight)
model = clf.fit(x_train, y_train)
y_pred_test_bin = model.predict(x_test).astype(int)
threshold = None
_ = eval_.test_results(y_test, y_pred_test_bin, threshold, beta=beta)


# In[ ]:


# -------------------- Plot test results -------------------- #
df = datasets_revised[index_test].reindex(dfs_x[index_test].index)
df['y'] = y_test
df['y_pred'] = y_pred_test_bin
c = crashes[index_test]
t_start = ['1956-01-01', '1971-01-01', '1976-01-01', '1983-01-01', '1995-01-01', '2004-01-01',\
           '2010-01-01']
t_end = ['1963-01-01', '1981-01-01', '1983-01-01', '1988-01-01', '2003-01-01', '2010-01-01',\
           '2016-01-01']
#plt.rcParams.update(plt.rcParamsDefault)
rcParams['figure.figsize'] = 10, 6
eval_.plot_test_results(df, c, t_start, t_end)


# In[ ]:


# -------------------- Current prediction S&P 500 -------------------- #
# train on all available data:
x_train_final, y_train_final, _, _ = data.get_train_test(dfs_x, dfs_y, dataset_names,\
        test_data=None)
C = [1, 1, 1]
class_weights = [{0:.06, 1:.94}, {0:.06, 1:.94}, {0:.08, 1:.92}]
dataset_original = ['^GSPC.txt']
dataset_name = ['S&P 500']
crash_threshold = [-0.0936]
data_new = DataLoader(dataset_original, dataset_name)
dataset_revised, crashes = data_new.get_data_revised(crash_threshold)
dfs_x_new, dfs_y_new = data_new.get_dfs_xy_predict(months=months)
x_new, _, _, _ = data_new.get_train_test(dfs_x_new, dfs_y_new, dataset_name, test_data=None)

for index_month in range(len(months)):
    y_train_final_ = y_train_final[:, index_month].astype(int)
    clf = svm.SVC(C=C[index_month], kernel=kernel, class_weight=class_weights[index_month])
    model = clf.fit(x_train_final, y_train_final_)
    y_pred_new_bin = model.predict(x_new).astype(int)
    current_pred = np.dot(np.linspace(0,1,21) / sum(np.linspace(0,1,21)), y_pred_new_bin[-21:])
    print(str(model_name) + ' prediction of a crash within ' + str(months[index_month]) \
          + ' months: ' + str(np.round(current_pred, 2)))


# ### Predicting Stock Market Crashes -- Comparison of Results
# 
# Linear Regression / Logistic Regression / SVM (linear kernel) / SVM (RBF kernel) / Decision Trees / RNN LSTM
# 
# 16 features for all models except RNN / 2 sequences of length 14 for RNN LSTMs
# 
# Predictions for crash withinin 1 month / 3 months / 6 months

# In[133]:


d = {}
d['Linear Regression'] = [0.02, 0.05, 0.14, 0.4, 0.95, 0.29, 0.14,\
                          0.36, 0.95, 0.27, 0.02, 0.03, 0.16, 0.35, 0.96, 0.28]
d['Logistic Regression'] = [0.02, 0.07, 0.11, 0.47, 0.93, 0.28, 0.11,\
                            0.42, 0.93, 0.26, 0.02, 0.07, 0.12, 0.45, 0.94, 0.29]
d['SVC (linear)'] = [0.02, 0.06, 0.12, 0.48, 0.93, 0.30, 0.12, 0.44,\
                     0.93, 0.28, 0.02, 0.06, 0.12, 0.44, 0.94, 0.29]
d['SVC (RBF)'] = [0.02, 0.08, 0.12, 0.60, 0.92, 0.33, 0.10, 0.49, 0.91,\
                  0.28, 0.02, 0.07, 0.09, 0.39, 0.93, 0.24]
d['Decision Tree'] = [0.02, 0.01, 0.99, 0.90, 1.00, 0.92, 0.10, 0.10,\
                      0.97, 0.10, 0.02, 0.01, 0.11, 0.10, 0.97, 0.10]
d['RNN LSTM'] = [0.02, 0.04, 0.18, 0.44, 0.96, 0.34, 0.17, 0.37, 0.95,\
                 0.29, 0.02, 0.04, 0.10, 0.28, 0.95, 0.21] 
d['random'] = [0.02, 0.05, 0.02, 0.05, 0.94, 0.04, 0.02, 0.05, 0.94, 0.04,\
              0.02, 0.05, 0.02, 0.05, 0.94, 0.04]
results_1m = pd.DataFrame.from_dict(d, orient='index')
results_1m.columns = ['positive_actual', 'positive_pred', 'precision_tr', 'recall_tr',\
                      'accuracy_tr', 'score_tr', 'precision_val','recall_val', 'accuracy_val',\
                      'score_val', 'positive_act', 'positive_pred', 'precision_t', 'recall_t',\
                      'accuracy_t', 'score_t']

d = {}
d['Linear Regression'] = [0.04, 0.17, 0.13, 0.5, 0.83, 0.31, 0.13, 0.5,\
                          0.83, 0.32, 0.04, 0.16, 0.15, 0.59, 0.84, 0.37]
d['Logistic Regression'] = [0.04, 0.16, 0.13, 0.47, 0.84, 0.31, 0.13, 0.46,\
                            0.84, 0.30, 0.04, 0.15, 0.15, 0.56, 0.85, 0.36]
d['SVC (linear)'] = [0.04, 0.14, 0.14, 0.48, 0.86, 0.33, 0.15, 0.46, 0.86,\
                     0.32, 0.04, 0.14, 0.16, 0.52, 0.87, 0.36]
d['SVC (RBF)'] = [0.04, 0.14, 0.17, 0.57, 0.86, 0.39, 0.15, 0.45, 0.86, 0.31,\
                  0.04, 0.14, 0.16, 0.52, 0.87, 0.36]
d['Decision Tree'] = [0.04, 0.04, 1.00, 0.99, 1.00, 0.99, 0.12, 0.12, 0.92,\
                      0.11, 0.04, 0.04, 0.07, 0.07, 0.92, 0.07]
d['RNN LSTM'] = [0.04, 0.15, 0.14, 0.5, 0.84, 0.33, 0.15, 0.47, 0.84, 0.32,\
                 0.04, 0.13, 0.15, 0.48, 0.87, 0.33] 
d['random'] = [0.04, 0.18, 0.04, 0.18, 0.19, 0.11, 0.04, 0.18, 0.19, 0.11,\
              0.04, 0.18, 0.04, 0.18, 0.19, 0.11]
results_3m = pd.DataFrame.from_dict(d, orient='index')
results_3m.columns = ['positive_actual', 'positive_pred', 'precision_tr', 'recall_tr',\
                      'accuracy_tr', 'score_tr', 'precision_val','recall_val', 'accuracy_val',\
                      'score_val', 'positive_act', 'positive_pred', 'precision_t', 'recall_t',\
                      'accuracy_t', 'score_t']

d = {}
d['Linear Regression'] = [0.08, 0.37, 0.14, 0.61, 0.65, 0.36, 0.14, 0.63,\
                          0.66, 0.37, 0.07, 0.36, 0.14, 0.68, 0.67, 0.38]
d['Logistic Regression'] = [0.08, 0.31, 0.15, 0.56, 0.7, 0.36, 0.15, 0.58,\
                            0.71, 0.36, 0.08, 0.31, 0.16, 0.66, 0.72, 0.40]
d['SVC (linear)'] = [0.08, 0.28, 0.15, 0.55, 0.73, 0.36, 0.16, 0.55, 0.73,\
                     0.36, 0.08, 0.28, 0.17, 0.6, 0.77, 0.40]
d['SVC (RBF)'] = [0.08, 0.32, 0.16, 0.67, 0.7, 0.42, 0.16, 0.62, 0.7, 0.38,\
                  0.08, 0.32, 0.15, 0.71, 0.69, 0.41]
d['Decision Tree'] = [0.08, 0.08, 1.00, 1.00, 1.00, 1.00, 0.15, 0.13, 0.87,\
                      0.13, 0.08, 0.08, 0.12, 0.12, 0.88, 0.12]
d['RNN LSTM'] = [0.08, 0.36, 0.15, 0.64, 0.66, 0.37, 0.14, 0.63, 0.66, 0.36,\
                 0.07, 0.35, 0.15, 0.71, 0.68, 0.40]
d['random'] = [0.08, 0.36, 0.08, 0.36, 0.61, 0.21, 0.08, 0.36, 0.61, 0.21,\
              0.08, 0.36, 0.08, 0.36, 0.61, 0.21]
results_6m = pd.DataFrame.from_dict(d, orient='index')
results_6m.columns = ['positive_actual', 'positive_pred', 'precision_tr', 'recall_tr',\
                      'accuracy_tr', 'score_tr', 'precision_val','recall_val', 'accuracy_val',\
                      'score_val', 'positive_act', 'positive_pred', 'precision_t', 'recall_t',\
                      'accuracy_t', 'score_t']


# In[134]:


print('Training results 1 month prediciton:')
display(results_1m.iloc[:,:10])
print('Training results 3 month prediciton:')
display(results_3m.iloc[:,:10])
print('Training results 6 month prediciton:')
display(results_6m.iloc[:,:10])
print('Test results 1 month prediciton:')
display(results_1m.iloc[:,10:])
print('Test results 3 month prediciton:')
display(results_3m.iloc[:,10:])
print('Test results 6 month prediciton:')
display(results_6m.iloc[:,10:])


# In[135]:


colors = ['royalblue', 'blueviolet', 'gold', 'coral', 'green', 'red', 'gray']
markers = ['s', 'o', 'D']
f = lambda m,c: plt.plot([],[],marker=m, color=c, ls="none")[0]
handles = [f('s', colors[i]) for i in range(7)]
handles += [f(markers[i], 'k') for i in range(3)]
labels = list(results_6m.index) + ['1 month prediction', '3 month prediction', '6 month prediction']
rcParams.update({'font.size': 16})
rcParams['figure.figsize'] = 10, 8
plt.style.use('seaborn-darkgrid')
x = list(results_1m['recall_t'])
y = list(results_1m['precision_t'])
for x_, y_, c_ in zip(x, y, colors):
    plt.scatter(x_, y_, marker='s', c=c_, linewidths=1, s=110, alpha=0.7)
x = list(results_3m['recall_t'])
y = list(results_3m['precision_t'])
for x_, y_, c_ in zip(x, y, colors):
    plt.scatter(x_, y_, marker='o', c=c_, linewidths=1, s=120, alpha=0.7)
x = list(results_6m['recall_t'])
y = list(results_6m['precision_t'])
for x_, y_, c_ in zip(x, y, colors):
    plt.scatter(x_, y_, marker='D', c=c_, linewidths=1, s=100, alpha=0.7)
plt.legend(handles, labels, loc=4, framealpha=1)
plt.title('Recall vs Precision all models')
plt.xlim(xmin=0, xmax=1)
plt.ylim(ymin=0, ymax=0.2)
plt.xlabel('Recall')
plt.ylabel('Precision')
plt.show()


# In[136]:


rcParams['figure.figsize'] = 10, 8
rcParams.update({'font.size': 18})
df = pd.concat([results_6m['score_t'], results_3m['score_t'], results_1m['score_t']], axis=1)
df.columns = ['6 month prediciton', '3 month prediciton', '1 month prediciton']
df = df.iloc[::-1]
df.plot(kind='barh', stacked=False, width=0.75, color=['mediumaquamarine','mediumseagreen','green'])
plt.title('F-beta score all models')
plt.xlabel('F-beta score (beta = 2)')
plt.legend(loc='best', bbox_to_anchor=(1, 0.5))
plt.show()


# In[ ]:





# In[ ]:





# ### Detecting Stock Market Crashes with Topological Data Analysis
# 
# Summary: In this section of my project I will display how topological data analysis (TDA) can be used as a descriptive tool to study stock market crashes based on past price information.
# 
# Data: I'll be working with the daily time series of the S&P 500 index, which measures the stock performance of the top 500 US companies.

# In[137]:


pip install openml


# In[138]:


pip install virtualenv


# In[139]:


pip install -r requirements.txt


# In[140]:


# Reload modules before executing user code
get_ipython().run_line_magic('load_ext', 'autoreload')
# Reload all modules every time before executing the Python code
get_ipython().run_line_magic('autoreload', '2')


# giotto-tda is a high-performance topological machine learning toolbox in Python built on top of scikit-learn and is distributed under the GNU AGPLv3 license. It is part of the Giotto family of open-source projects

# In[141]:


pip install giotto-tda


# In[142]:


pip install plotting


# In[143]:


pip install pypfotp


# In[144]:


# Data source
import yfinance as yf

# Data wrangling
import numpy as np
import pandas as pd

# Data viz
import seaborn as sns
import matplotlib.pyplot as plt
from pandas.plotting import register_matplotlib_converters
register_matplotlib_converters()

get_ipython().run_line_magic('matplotlib', 'inline')
get_ipython().run_line_magic('config', "InlineBackend.figure_format = 'retina'")
sns.set(color_codes=True, rc={'figure.figsize':(12, 4)})
sns.set_palette(sns.color_palette('muted'))

# TDA magic
import gtda.time_series as ts
import gtda.diagrams as diag
import gtda.homology as hl
import gtda.graphs as gr
from gtda.plotting import plot_diagram, plot_point_cloud
from gtda.pipeline import Pipeline


# ### Load and explore S&P 500 time series
# 
# I will now load and explore historical data from my local dataset

# In[145]:


import pandas as pd

sp500_df = pd.read_csv("^GSPC.txt")

sp500_df['Date'] = pd.to_datetime(sp500_df['Date'])
sp500_df.set_index('Date', inplace=True)

sp500_df.head()


# In[146]:


sp500_df.tail()


# In[147]:


sp500_df.shape


# I am interested in the Close price values, so let's take a look at the complete time series:

# In[148]:


price_df = sp500_df['Close']
price_df.plot()
plt.title('Close Price')
plt.show()


# As expected, we can see the bursting of the dot-com bubble between 2000-2004, as well as the 2008 financial crisis.

# ### Resampling
# 
# Since the markets are closed over weekends, let's resample to evenly-spaced daily values and focus on detecting crashes after 1980:

# In[149]:


start_year = '1980'
price_resampled_df = price_df.resample('24H').pad()[start_year:]


# In[150]:


plt.plot(price_resampled_df)
plt.title('Price')
plt.show()


# ### Time series as point clouds -- Takens' embedding
# 
# Discrete time series – that is, time series indexed by a sequence of times 
#  – are typically visualised as scatter plots in two dimensions. Points in the plot have times as their horizontal co-ordinates, and the corresponding values 
#  of the variable of interest, y, as their vertical co-ordinates.
# 
# This representation makes the local behaviour of the time series easy to track by scanning the plot from left to right. But it is often ineffective at conveying important effects which may be occurring over larger time scales.
# 
# One well-known set of techniques for capturing periodic behaviour comes from Fourier analysis. For instance, the discrete Fourier transform of a temporal window over the time series gives information on whether the signal in that window arises as the sum of a few simple periodic signals.
# 
# Here I want to present a different way of encoding a time-evolving process. It is based on the idea that some key properties of the dynamics (including, but more general than, periodicity or quasi-periodicity as seen by Fourier analysis) can be unveiled very effectively in higher dimensions. I will be able to represent a univariate time series (or a single temporal window over that time series) as a point cloud, i.e. a set of vectors in a Euclidean space of arbitrary dimension.
# 
# 
# The next step creates a time-delay embedding technique which is also called Takens' embedding after Floris Takens, who demonstrated its significance with a celebrated theorem in the context of nonlinear dynamical systems.
# 
# The outer window allows us to apply Takens embedding locally on a certain interval rather than over the whole time series. The result of this procedure is therefore a time series of point clouds with possibly interesting topologies.

# In[151]:


embedding_dimension = 3
embedding_time_delay = 2


# Next I need to initialise the embedder to represent the price time series as a time series of point clouds:

# In[152]:


embedder = ts.SingleTakensEmbedding(
    parameters_type="fixed",
    dimension=embedding_dimension,
    time_delay=embedding_time_delay,
    n_jobs=-1,
)


# Now that the embedder is initialised, it is a simple matter to obtain an array of embeddings, where each element is a 3-dimensional vector:

# In[153]:


price_values = price_resampled_df.values
price_embedded = embedder.fit_transform(price_values)

embedder_time_delay = embedder.time_delay_
embedder_dimension = embedder.dimension_


# Next I will apply a sliding window to obtain the point clouds per window. We choose the window size such that each interval will span a period of 36 days:

# In[154]:


window_size = 31
window_stride = 4


# In[155]:


sliding_window = ts.SlidingWindow(size=window_size, stride=window_stride)
price_embedded_windows = sliding_window.fit_transform(price_embedded)


# Now that I have the point clouds, let's visualise one of them:

# In[156]:


window_num = 42
point_cloud = price_embedded_windows[window_num][:, :3]
plot_point_cloud(point_cloud)


# A simple baseline
# Here I create a simple baseline that tracks the first derivative of the time series over a sliding window. By using the SlidingWindow class from giotto-learn I can quickly obtain arrays that are amenable for the scikit-learn APIs:

# In[157]:


window_size_price = window_size + embedder_dimension * embedder_time_delay - 2
sliding_window_price = ts.SlidingWindow(size=window_size_price, stride=window_stride)
window_indices = sliding_window_price.slice_windows(price_values)
price_windows = sliding_window_price.fit_transform(price_values)


# In[158]:


abs_derivative_of_means = np.abs(np.mean(np.diff(price_windows, axis=0), axis=1))


# Now I will define time index to combine with numpy arrays

# In[159]:


indices = [win[1] - 1 for win in window_indices[1:]]
time_index_derivs = price_resampled_df.iloc[indices].index


# In[160]:


resampled_close_price_derivs = price_resampled_df.loc[time_index_derivs]


# In[161]:


plt.figure(figsize=(15,5))
plt.plot(time_index_derivs, abs_derivative_of_means, color='#1f77b4')
plt.title('First Derivative of the S&P 500 Index')
plt.show()


# In[162]:


start_date = "1981-01-01"
end_date = "2005-01-01"
threshold = 0.3
distances = abs_derivative_of_means
time_index_derivs = time_index_derivs
price_resampled_derivs = resampled_close_price_derivs
metric_name = 'First Derivative'

mask = (time_index_derivs >= start_date) & (time_index_derivs <= end_date)
filtered_time_index = time_index_derivs[mask]
filtered_distances = distances[mask]

fig, ax = plt.subplots(figsize=(10, 6))

ax.plot(filtered_time_index, filtered_distances, label=metric_name, color='blue')

crash_mask = filtered_distances > threshold
ax.fill_between(filtered_time_index, 0, filtered_distances, where=crash_mask, color='red', alpha=0.5, label='Crash Detection')

ax.set_title('Crash Detections')
ax.set_xlabel('Time')
ax.set_ylabel(metric_name)
ax.legend()

plt.show()


# The first derivative appears to give an indication of where crashes have happened in the past, albeit with quite some noise around each event.

# ### Persistence diagrams
# 
# The first step in a TDA pipeline typically involves calculating persistence diagrams, which encode topological information on the dynamics in the embedding space. The horizontal axis corresponds to the moment in which a homological generator is born, while the vertical axis corresponds to the moments in which an homological generator dies.

# I will now define the number of homology dimensions to track

# In[163]:


homology_dimensions = (0, 1)
VR = hl.VietorisRipsPersistence(homology_dimensions=homology_dimensions, n_jobs=-1)
diagrams = VR.fit_transform(price_embedded_windows)


# In the plot below for a single window, the generators of each homology dimension H0 and H1 are coloured differently:

# In[164]:


VR.plot(diagrams, sample=window_num)


# ### Homological derivatives
# 
# Given a persistence diagram, there are a number of possible features that can derived from it. For my application, I am interested in calculating the distance between diagrams obtained from two successive windows. Although one can calculate this directly from the PairwiseDistance class, I show below how one can make use of giotto-learn's API to create a custom transformer:

# In[165]:


from joblib import Parallel, delayed, effective_n_jobs

from sklearn.utils import gen_even_slices
from sklearn.utils.validation import check_is_fitted

from gtda.diagrams import PairwiseDistance
from gtda.diagrams._metrics import _parallel_pairwise, landscapes, betti_curves
from gtda.diagrams._utils import _subdiagrams
from gtda.utils.validation import check_diagrams


class HomologicalDerivative(PairwiseDistance):
    def __init__(self, **kw_args):
        super().__init__(**kw_args)

    def _derivatives_generic(self, X, s):

        return np.array(
            [
                _parallel_pairwise(
                    np.expand_dims(X[t + 1], axis=0),
                    np.expand_dims(X[t], axis=0),
                    self.metric,
                    self.effective_metric_params_,
                    self.homology_dimensions_,
                    self.n_jobs,
                )[0, 0]
                for t in range(s.start, s.stop, 1)
            ]
        )

    def _derivatives(self, subdiagrams, kind, dim, params):
        n_samples, n_points = subdiagrams.shape[:2]
        if kind == "landscape":
            n_layers = min(params["n_layers"], n_points)
            features = landscapes(subdiagrams, params["samplings"][dim], n_layers)
        elif kind == "betti":
            features = betti_curves(subdiagrams, params["samplings"][dim])
        features = (features[1:] - features[:-1]).reshape(n_samples - 1, -1)
        features = np.linalg.norm(features, axis=1, ord=params["p"])

        return (params["step_sizes"][dim] ** (1 / params["p"])) * features

    def fit(self, X, y=None):
        super().fit(X, y)

        return self

    def transform(self, X, y=None):
        check_is_fitted(self, ["effective_metric_params_", "homology_dimensions_"])
        X = check_diagrams(X)

        if self.metric in ["landscape", "betti"]:
            Xt = Parallel(n_jobs=self.n_jobs)(
                delayed(self._derivatives)(
                    _subdiagrams(X[s.start : s.stop + 1], [dim], remove_dim=True),
                    self.metric,
                    dim,
                    self.effective_metric_params_,
                )
                for dim in self.homology_dimensions_
                for s in gen_even_slices(len(X) - 1, effective_n_jobs(self.n_jobs))
            )
            Xt = np.concatenate(Xt)
            Xt = Xt.reshape(len(self.homology_dimensions_), len(X) - 1).T
        else:
            Xt = Parallel(n_jobs=self.n_jobs)(
                delayed(self._derivatives_generic)(X, s)
                for s in gen_even_slices(len(X) - 1, effective_n_jobs(self.n_jobs))
            )
            Xt = np.concatenate(Xt)

        if self.order is not None:
            Xt = np.linalg.norm(Xt, axis=1, ord=self.order)

        return Xt


# ### Landscape distances
# 
# With omy transformer defined, I will use it to calculate the successive distance between diagrams using the landscape distance:

# In[166]:


metric_params = {"p": 2, "n_layers": 10, "n_bins": 1000}

landscape_hom_der = HomologicalDerivative(
    metric="landscape", metric_params=metric_params, order=2, n_jobs=-1
)
landscape_succ_dists = landscape_hom_der.fit_transform(diagrams)


# In[167]:


plt.figure(figsize=(16, 4))
plt.subplot(1, 2, 1)
plt.plot(time_index_derivs, landscape_succ_dists, color="#1f77b4")
plt.title("Landscape Distances for S&P 500 Index")

plt.subplot(1, 2, 2)
plt.plot(resampled_close_price_derivs, "#1f77b4")
plt.title("Price")
plt.show()


# ### Distances among diagrams using Betti curves
# 
# In this section I show how to compute distances among persistece diagrams. There are many notions of distances: here I use the LP norm of the Betti curves.

# In[168]:


metric_params = {"p": 2, "n_bins": 1000}


bettiHomDer = HomologicalDerivative(
    metric='betti', metric_params=metric_params, order=2, n_jobs=-1
)
betti_succ_dists = bettiHomDer.fit_transform(diagrams)


# In[169]:


plt.figure(figsize=(16, 4))
plt.subplot(1, 2, 1)
plt.plot(time_index_derivs, betti_succ_dists)
plt.title('Norm of L^p difference')

plt.subplot(1, 2, 2)
plt.plot(resampled_close_price_derivs)
plt.title('Price')
plt.show()


# In[170]:


plt.figure(figsize=(15, 5))
plt.subplot(1, 2, 1)
plt.plot(time_index_derivs, landscape_succ_dists, "#1f77b4")
plt.title("Landscape Distances of the S&P 500 Index")

plt.subplot(1, 2, 2)
plt.plot(time_index_derivs, betti_succ_dists, "#1f77b4")
plt.title('Betti Curve Distances of the S&P 500 Index')
plt.show()


# ### Topological indicators for crashes
# 
# By comparing the different ways to measure change of topological signature, it seems that the landscape approach carries more information and is more robust to noise, let's investigate a bit more what is happening around selected market crashes using the landscape distance.
# 
# Let's investigate the last two major market crashes.
# 
# #### dot-com crash: from March 11, 2000, to October 9, 2004
# 
# #### Subprime mortgage crisis: from December 2007 – June 2009

# In[171]:


start_date = "1990-01-01"
end_date = "2005-01-01"
threshold = 0.3

distances = landscape_succ_dists
time_index_derivs = time_index_derivs
price_resampled_derivs = resampled_close_price_derivs
metric_name = 'Landscape Distance'

mask = (time_index_derivs >= start_date) & (time_index_derivs <= end_date)
filtered_time_index = time_index_derivs[mask]
filtered_distances = distances[mask]

fig, ax = plt.subplots(figsize=(10, 6))

ax.plot(filtered_time_index, filtered_distances, label=metric_name, color='blue')

crash_mask = filtered_distances > threshold
ax.fill_between(filtered_time_index, 0, filtered_distances, where=crash_mask, color='red', alpha=0.5, label='Crash Detection')

ax.set_title('Crash Detections')
ax.set_xlabel('Time')
ax.set_ylabel(metric_name)
ax.legend()

plt.show()


# From the right side of the plot the metric, has been able to identify part of the region in time when the dot-com bubble began to burst.
# 
# The following plot examine's the financial crisis from 2008

# In[172]:


start_date = "2005-01-01"
end_date = "2012-01-01"
threshold = 0.3
distances = landscape_succ_dists
time_index_derivs = time_index_derivs
price_resampled_derivs = resampled_close_price_derivs
metric_name = 'Landscape Distance'

mask = (time_index_derivs >= start_date) & (time_index_derivs <= end_date)
filtered_time_index = time_index_derivs[mask]
filtered_distances = distances[mask]

fig, ax = plt.subplots(figsize=(10, 6))

ax.plot(filtered_time_index, filtered_distances, label=metric_name, color='blue')

crash_mask = filtered_distances > threshold
ax.fill_between(filtered_time_index, 0, filtered_distances, where=crash_mask, color='red', alpha=0.5, label='Crash Detection')

ax.set_title('Crash Detections')
ax.set_xlabel('Time')
ax.set_ylabel(metric_name)
ax.legend()
plt.show()


# Again, the homological derivative has captured part of the region where the market was crashing.
# 
# I will now compaire the basline model against the topological features.

# In[173]:


start_date = "1981-01-01"
end_date = "2022-01-01"
threshold = 0.3
distances_1 = abs_derivative_of_means
distances_2 = landscape_succ_dists
time_index_derivs = time_index_derivs
price_resampled_derivs = resampled_close_price_derivs

mask = (time_index_derivs >= start_date) & (time_index_derivs <= end_date)
filtered_time_index = time_index_derivs[mask]
filtered_distances_1 = distances_1[mask]
filtered_distances_2 = distances_2[mask]

fig, ax = plt.subplots(figsize=(10, 6))

ax.plot(filtered_time_index, filtered_distances_1, label='Metric 1', color='blue')
ax.plot(filtered_time_index, filtered_distances_2, label='Metric 2', color='green')

crash_mask_1 = filtered_distances_1 > threshold
crash_mask_2 = filtered_distances_2 > threshold

ax.fill_between(filtered_time_index, 0, filtered_distances_1, where=crash_mask_1 & crash_mask_2, color='purple', alpha=0.5, label='Both Metrics')
ax.fill_between(filtered_time_index, 0, filtered_distances_1, where=crash_mask_1 & ~crash_mask_2, color='red', alpha=0.5, label='Metric 1 Only')
ax.fill_between(filtered_time_index, 0, filtered_distances_2, where=~crash_mask_1 & crash_mask_2, color='green', alpha=0.5, label='Metric 2 Only')

ax.set_title('Crash Comparisons')
ax.set_xlabel('Time')
ax.set_ylabel('Distances')
ax.legend()

plt.show()


# Metric 2 clearly demonstrate historical bubbles that have happened.

# In[ ]:





# In my next approach, I will approach it as a binary classification task, to predict if a market crash will happen or not

# In[174]:


ticker = '^GSPC'  
start_date = '2000-01-01'
end_date = '2023-12-25'

stock_data = pd.read_csv("^GSPC.txt")


# #### Feature Engineering
# 
# I will engineer relevant features from the stock data using simple moving averages as features

# In[175]:


stock_data['MovingAverage_5'] = stock_data['Adj Close'].rolling(window=5).mean()
stock_data['MovingAverage_20'] = stock_data['Adj Close'].rolling(window=20).mean()
stock_data['MovingAverage_50'] = stock_data['Adj Close'].rolling(window=50).mean()
stock_data['MovingAverage_200'] = stock_data['Adj Close'].rolling(window=200).mean()
stock_data.dropna(inplace=True)


# #### Labeling Market Crashes
# 
# I will now distinguish between market conditions and crashes, using a simple treshold based approach where a daily return below a certain value will be labeled as a market crash.

# In[176]:


def create_labels(data, threshold=0.0):
    data['MarketDirection'] = 0
    data.loc[data['DailyReturns'] <= -threshold, 'MarketDirection'] = 1

stock_data['DailyReturns'] = stock_data['Adj Close'].pct_change()

create_labels(stock_data, threshold=0.05)


# To predict stock market crashes, I will employ an Random Forest Classifier. Ensemble methods combine multiple machine learning models to make more accurate predictions.

# In[177]:


from sklearn.ensemble import RandomForestClassifier


# #### Data Splitting
# 
# I will split the data into training and testing sets to ensure I have a separate dataset to evaluate the model's performance.

# In[178]:


from sklearn.model_selection import train_test_split

X = stock_data[['MovingAverage_5', 'MovingAverage_20', 'MovingAverage_50', 'MovingAverage_200']]
y = stock_data['MarketDirection']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)


# I  will now build and train the Random Forest Classifier

# In[179]:


model = RandomForestClassifier(n_estimators=100, random_state=42)

model.fit(X_train, y_train)


# I will now evaluate the model's performance and visualize the results to gain insights into its effectiveness in predicting stock market crashes.

# In[180]:


from sklearn.metrics import accuracy_score, classification_report
import matplotlib.pyplot as plt

y_pred = model.predict(X_test)

accuracy = accuracy_score(y_test, y_pred)
print(f"Model Accuracy: {accuracy:.2f}")

classification_report_str = classification_report(y_test, y_pred)
print("Classification Report:")
print(classification_report_str)

feature_importances = model.feature_importances_
features = X.columns

plt.figure(figsize=(8, 6))
plt.bar(features, feature_importances)
plt.title('Feature Importances')
plt.xlabel('Features')
plt.ylabel('Importance')
plt.xticks(rotation=45)
plt.show()


# Conclusions
# 
# I leveraged Random Forest Classifier, to predict market crashes using historical stock data. Additionally, we visualized the feature importances to gain insights into the crucial factors affecting the predictions.
# 
# 

# ### BSADF test for Bubble Detection algorithm developed by Philips and Yu (2011) and Philips et al. (2015)
# 
# Backward supremum augmented Dickey-Fuller (BSADF) is an effective method for identifying the amount of initial and end points of bubbles.

# In[ ]:


ticker = '^GSPC'  
start_date = '2020-01-01'
end_date = '2023-12-25'

prices = yf.download(ticker, start, end)('Close')


# Imputing the parameters

# In[ ]:


r0 = int(len(prices)*0.1)


# Specify lags for the Augmented Dickey-Fuller (ADF) test

# In[ ]:


adf_lags = 3


# Critical value of the right tailed ADF-test (95%) from Philips et al. (2015)

# In[ ]:


crit = 1.49


# Transforming Data

# In[ ]:


log_prices = np.array(np.log(prices))
delta_log_prices = log_prices[1:] - log_prices[:-1]
n = len (delta_log_prices)
BSADF = no.array([])


# Calculating ADF stats

# In[ ]:


for r2 in range(r0,n):
    ADFS = np.array([])
    for r1 in range(0,r2-r0+1):
        X0 = log_prices[r1:r2+1]
        X = pd.DataFrame()
        X[0] = X0
        for j in range(1,adf_lags+1):
            X[j] = np.append(np.zeros(j),delta_log_prices[r1:r2+1-j])
        X = np.array(X)
        Y = delta_log_prices[r1:r2+1]
        reg = sm.OLS(Y,sm.add_constant(X))
        res = reg.fit()
        ADFS = np.append(ADFS, res.params[1]/res.bse[1])
    BSADF = np.append(BSADF, max(ADFS))


# Results

# In[ ]:


plt.rc('xtick',labelsize = 8)
plt.plot(prices.index[r0+1:],BSADF)
plt.plot(prices.index[r0+1:],np.ones(len(BSADF))*crit)


# Printing dates when bubbles were detected

# In[ ]:


print(prices.index[r0+1:][BSADF > crit])


# ### Generalized AutoRegressive Conditional Heteroskedasticity (GARCH)
# 
# Is a statistical model used in analyzing time-series data where the variance error is believed to be serially autocorrelated. GARCH models assume that the variance of the error term follows an autoregressive moving average process.
# 
# GARCH is a statistical modeling technique used to help predict the volatility of returns on financial assets.
# 
# GARCH is appropriate for time series data where the variance of the error term is serially autocorrelated following an autoregressive moving average process. 
# 
# GARCH is useful to assess risk and expected returns for assets that exhibit clustered periods of volatility in returns.
# 
# I will once again use S&P index ^GSPC

# Calculating returns

# In[ ]:


returns = np.array(prices)[1:]/np.array(prices)[:-1] - 1


# In[ ]:


mean = np.average(returns)
var = np.std(returns)**2
def garch_mle(params):
    mu = params[0]
    omega = params[1]
    alpha = params[2]
    beta = params[3]
    long_run = (omega/(1 - alpha - beta))**(1/2)
    resid = returns - mu
    realised = abs(resid)
    conditional = np.zeros(len(returns))
    conditional[0] =  long_run
    for t in range(1,len(returns)):
        conditional[t] = (omega + alpha*resid[t-1]**2 + beta*conditional[t-1]**2)**(1/2)
    likelihood = 1/((2*np.pi)**(1/2)*conditional)*np.exp(-realised**2/(2*conditional**2))
    log_likelihood = np.sum(np.log(likelihood))
    return -log_likelihood
res = spop.minimize(garch_mle, [mean, var, 0, 0], method='Nelder-Mead')
params = res.x
mu = res.x[0]
omega = res.x[1]
alpha = res.x[2]
beta = res.x[3]
log_likelihood = -float(res.fun)
long_run = (omega/(1 - alpha - beta))**(1/2)
resid = returns - mu
realised = abs(resid)
conditional = np.zeros(len(returns))
conditional[0] =  long_run
for t in range(1,len(returns)):
    conditional[t] = (omega + alpha*resid[t-1]**2 + beta*conditional[t-1]**2)**(1/2)
print('GARCH model parameters')
print('')
print('mu '+str(round(mu, 6)))
print('omega '+str(round(omega, 6)))
print('alpha '+str(round(alpha, 4)))
print('beta '+str(round(beta, 4)))
print('long-run volatility '+str(round(long_run, 4)))
print('log-likelihood '+str(round(log_likelihood, 4)))
plt.figure(1)
plt.rc('xtick', labelsize = 10)
plt.plot(prices.index[1:],realised)
plt.plot(prices.index[1:],conditional)
plt.show()


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:


References:
    
https://www.tableau.com/learn/articles/time-series-analysis
    
https://machinelearningmastery.com/develop-arch-and-garch-models-for-time-series-forecasting-in-python/
    
https://www.cboe.com/tradable_products/vix/
    
https://plotly.com/python/candlestick-charts/
    
https://www.investopedia.com/terms/r/rsi.asp
    
http://www.sca.isr.umich.edu/
    
https://www.statistics.com/glossary/differencing-of-time-series/
    
https://www.tableau.com/learn/articles/time-series-forecasting

https://machinelearningmastery.com/gentle-introduction-long-short-term-memory-networks-experts/


# In[ ]:




